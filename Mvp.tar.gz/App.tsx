import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, BadgeCheck, Bell, CalendarDays, Camera, Check, ChevronRight, Clock, Coffee, Copy, Database, Globe, Heart, Home, Languages, Lock, MapPin, MessageCircle, Palette, ShieldCheck, Sparkles, Trash2, Upload, Users, Vibrate } from 'lucide-react';

type Tab = 'home' | 'recommend' | 'calendar' | 'my';
type View = 'main' | 'request' | 'dresscode' | 'feedback' | 'checkin' | 'code' | 'share' | 'report' | 'profile' | 'meeting-check' | 'noshow' | 'noshow-result';
type CheckinStage = 'permission' | 'checking' | 'location' | 'fallback' | 'waitingPartner' | 'verified' | 'notMet';
const NOSHOW_REASONS = ['연락 없이 안 옴', '30분 이상 지각', '장소에 안 옴'];
const REPORT_REASONS = ['허위 프로필', '부적절한 사진', '욕설·비매너', '노쇼·연락 두절', '기타'];
type VerifyType = 'job' | 'student' | 'business' | 'later';
type Nationality = 'korean' | 'foreigner';
type MyGender = '남성' | '여성' | '기타';
type DesiredGender = '남성' | '여성' | '모두';
type UiLang = 'ko' | 'en' | 'ja' | 'zh';
type IntroMode = 'original' | 'translated';
type Profile = { id: number; name: string; age: number; area: string; badge: string; verified: boolean; faceVerified: boolean; job: string; intro: string; origLang: UiLang; introByLang: Record<UiLang, string>; dates: string[]; grad: string; initial: string };

const FOREIGN_COUNTRIES = [
  { id: '미국', label: '미국', flag: '🇺🇸', lang: 'en' as UiLang },
  { id: '일본', label: '일본', flag: '🇯🇵', lang: 'ja' as UiLang },
  { id: '중국', label: '중국', flag: '🇨🇳', lang: 'zh' as UiLang },
  { id: '기타', label: '기타', flag: '🌍', lang: 'en' as UiLang },
];
const LANGUAGE_OPTIONS = [
  { id: 'ko' as UiLang, label: '한국어' },
  { id: 'en' as UiLang, label: 'English' },
  { id: 'ja' as UiLang, label: '日本語' },
  { id: 'zh' as UiLang, label: '中文' },
];
const LANG_LABEL: Record<UiLang, string> = { ko: '한국어', en: 'English', ja: '日本語', zh: '中文' };
const TRANSLATED: Record<Exclude<UiLang, 'ko'>, { dateRequest: string; todayRec: string; header: string; accept: string }> = {
  en: { dateRequest: 'Send Date Request', todayRec: "Today's 6 recommendations", header: 'A day to meet and get to know each other', accept: 'Accept' },
  ja: { dateRequest: 'デートを申し込む', todayRec: '今日のおすすめ6名', header: '会って知り合う一日', accept: '承認する' },
  zh: { dateRequest: '发送约会申请', todayRec: '今日推荐6人', header: '见面相识的一天', accept: '接受' },
};

const DRESS_COLORS = [
  { id: 'blue', label: '파란색 계열', desc: '파란색 계열 상의', swatch: '#4E7FA0' },
  { id: 'white', label: '흰색', desc: '흰색 상의', swatch: '#FFFFFF' },
  { id: 'black', label: '검은색', desc: '검은색 상의', swatch: '#2B2622' },
  { id: 'beige', label: '베이지', desc: '베이지색 상의', swatch: '#E8D9BE' },
  { id: 'green', label: '초록색 계열', desc: '초록색 계열 상의', swatch: '#6E9A7E' },
  { id: 'custom', label: '기타 - 직접 적기', desc: '직접 입력 상의', swatch: '#F2A08D' },
];
const DRESS_ITEMS = [
  { id: 'coffee', label: '커피 들고 있기', short: '커피', emoji: '☕' },
  { id: 'book', label: '책 들고 있기', short: '책', emoji: '📖' },
  { id: 'black-bag', label: '검은 가방', short: '검은 가방', emoji: '👜' },
  { id: 'hat', label: '모자', short: '모자', emoji: '🧢' },
  { id: 'glasses', label: '안경', short: '안경', emoji: '👓' },
  { id: 'custom', label: '기타 - 직접 적기', short: '직접 입력', emoji: '✏️' },
];

const PROFILES: Profile[] = [
  { id: 1, name: '지우', age: 29, area: '성수', badge: '직장 인증', verified: true, faceVerified: true, job: '콘텐츠 기획자', intro: '주말엔 전시 보고, 평일엔 좋은 커피 찾으러 다녀요.', origLang: 'ko', introByLang: { ko: '주말엔 전시 보고, 평일엔 좋은 커피 찾으러 다녀요.', en: 'On weekends I visit exhibitions, and on weekdays I look for good coffee.', ja: '週末は展示を見て、平日はおいしいコーヒーを探しに行きます。', zh: '周末看展览，平日寻找好咖啡。' }, dates: ['11/19 수 19:00', '11/21 금 19:30', '11/22 토 15:00'], grad: 'linear-gradient(135deg,#F2A08D,#E85D3F)', initial: '지' },
  { id: 2, name: '서연', age: 27, area: '연남', badge: '직장 인증', verified: true, faceVerified: true, job: '브랜드 디자이너', intro: 'I love spending time walking and talking.', origLang: 'en', introByLang: { ko: '산책하면서 대화 나누는 시간을 좋아해요.', en: 'I love spending time walking and talking.', ja: '散歩しながら話す時間が好きです。', zh: '我喜欢边散步边聊天的时间。' }, dates: ['11/20 목 19:00', '11/22 토 14:00'], grad: 'linear-gradient(135deg,#A8C4A0,#6E9A7E)', initial: '서' },
  { id: 3, name: '민준', age: 31, area: '강남', badge: '사업자 인증', verified: true, faceVerified: true, job: '작은 카페 운영', intro: '사람 만나는 일을 좋아해서, 직접 만든 공간이 있어요.', origLang: 'ko', introByLang: { ko: '사람 만나는 일을 좋아해서, 직접 만든 공간이 있어요.', en: 'I love meeting people, so I have a space I made myself.', ja: '人に会うのが好きで、自分で作った場所があります。', zh: '因为喜欢见人，所以有了自己打造的空间。' }, dates: ['11/19 수 19:30', '11/23 일 16:00'], grad: 'linear-gradient(135deg,#EBCB8B,#C98B4B)', initial: '민' },
  { id: 4, name: '하윤', age: 28, area: '홍대', badge: '학생 인증', verified: true, faceVerified: true, job: '대학원생', intro: '展示とインディー映画、静かな会話が好きです。', origLang: 'ja', introByLang: { ko: '전시와 독립영화, 조용한 대화를 좋아합니다.', en: 'I like exhibitions, indie films, and quiet conversations.', ja: '展示とインディー映画、静かな会話が好きです。', zh: '喜欢展览、独立电影和安静的对话。' }, dates: ['11/21 금 18:30', '11/22 토 15:30'], grad: 'linear-gradient(135deg,#C9B8E6,#8A6FB8)', initial: '하' },
  { id: 5, name: '도현', age: 30, area: '잠실', badge: '직장 인증', verified: true, faceVerified: true, job: '개발자', intro: '运动后吃晚饭是最幸福的时候。', origLang: 'zh', introByLang: { ko: '운동 후 먹는 저녁이 제일 행복해요.', en: 'Dinner after exercise is the happiest moment.', ja: '運動の後の夕食が一番幸せです。', zh: '运动后吃晚饭是最幸福的时候。' }, dates: ['11/19 수 20:00', '11/21 금 19:00'], grad: 'linear-gradient(135deg,#9AC0D8,#4E7FA0)', initial: '도' },
  { id: 7, name: '준서', age: 29, area: '성수', badge: '사업자 인증', verified: true, faceVerified: true, job: '베이커리 운영', intro: '새로 구운 빵 냄새 맡으며 하루를 시작해요.', origLang: 'ko', introByLang: { ko: '새로 구운 빵 냄새 맡으며 하루를 시작해요.', en: 'I start my day smelling freshly baked bread.', ja: '焼きたてのパンの香りで一日を始めます。', zh: '闻着刚出炉的面包香开始一天。' }, dates: ['11/22 토 11:00', '11/23 일 15:00'], grad: 'linear-gradient(135deg,#E8C9A0,#B98A52)', initial: '준' },
  { id: 6, name: '채원', age: 26, area: '이태원', badge: '미인증', verified: false, faceVerified: true, job: '일러스트레이터', intro: 'Drawing and walking around the neighborhood is my everyday life.', origLang: 'en', introByLang: { ko: '그림 그리고, 동네 산책하는 게 일상이에요.', en: 'Drawing and walking around the neighborhood is my everyday life.', ja: '絵を描いて、近所を散歩するのが日常です。', zh: '画画、在附近散步是我的日常。' }, dates: ['11/20 목 18:00', '11/23 일 14:00'], grad: 'linear-gradient(135deg,#F3B7C7,#D96E8D)', initial: '채' },
  { id: 8, name: '예진', age: 28, area: '강남', badge: '미인증', verified: false, faceVerified: true, job: '마케터', intro: '재밌는 이야기 듣는 걸 좋아해요. 잘 웃어요.', origLang: 'ko', introByLang: { ko: '재밌는 이야기 듣는 걸 좋아해요. 잘 웃어요.', en: 'I love hearing fun stories. I laugh a lot.', ja: '楽しい話を聞くのが好きです。よく笑います。', zh: '喜欢听有趣的故事，经常笑。' }, dates: ['11/19 수 19:00', '11/21 금 20:00'], grad: 'linear-gradient(135deg,#F0A6A0,#D65F5F)', initial: '예' },
  { id: 9, name: '시우', age: 32, area: '연남', badge: '미인증', verified: false, faceVerified: true, job: '건축가', intro: '동네 골목을 걷다 보면 이야기가 생기더라고요.', origLang: 'ko', introByLang: { ko: '동네 골목을 걷다 보면 이야기가 생기더라고요.', en: 'Walking through neighborhood alleys always brings up new stories.', ja: '近所の路地を歩いていると、話が生まれます。', zh: '走在小区胡同里，总会有新的故事。' }, dates: ['11/21 금 19:30', '11/22 토 16:00'], grad: 'linear-gradient(135deg,#A9C7B3,#5F8F78)', initial: '시' },
  { id: 10, name: '다은', age: 27, area: '홍대', badge: '미인증', verified: false, faceVerified: true, job: '대학원생', intro: 'カフェで本を読んで、たまに公演を見に行きます。', origLang: 'ja', introByLang: { ko: '카페에서 책 읽고, 가끔은 공연 보러 가요.', en: 'I read books at cafés and sometimes go to performances.', ja: 'カフェで本を読んで、たまに公演を見に行きます。', zh: '在咖啡馆看书，偶尔去看演出。' }, dates: ['11/20 목 19:30', '11/22 토 13:00'], grad: 'linear-gradient(135deg,#B9C9E8,#6C82B8)', initial: '다' },
  { id: 11, name: '현우', age: 30, area: '잠실', badge: '미인증', verified: false, faceVerified: true, job: '영상 편집자', intro: '좋은 장면을 찾는 것처럼, 좋은 대화를 찾고 있어요.', origLang: 'ko', introByLang: { ko: '좋은 장면을 찾는 것처럼, 좋은 대화를 찾고 있어요.', en: 'Like finding a good scene, I am looking for a good conversation.', ja: '良い場面を探すように、良い会話を探しています。', zh: '像寻找好画面一样，我在寻找好的对话。' }, dates: ['11/20 목 19:00', '11/22 토 17:00'], grad: 'linear-gradient(135deg,#C9A8D8,#7E5FA0)', initial: '현' },
  { id: 12, name: '소윤', age: 26, area: '연남', badge: '미인증', verified: false, faceVerified: true, job: '플로리스트', intro: '像花一样，我喜欢慢慢了解的相遇。', origLang: 'zh', introByLang: { ko: '꽃처럼, 천천히 알아가는 만남을 좋아해요.', en: 'Like a flower, I like meetings where we get to know each other slowly.', ja: '花のように、ゆっくり知り合う出会いが好きです。', zh: '像花一样，我喜欢慢慢了解的相遇。' }, dates: ['11/21 금 18:00', '11/23 일 13:00'], grad: 'linear-gradient(135deg,#F2C9A0,#D98A4B)', initial: '소' },
];
const MY_INTRO_DEFAULT = '주말엔 전시 보고, 평일엔 좋은 커피 찾으러 다녀요.';
const MY_INTRO_EN = 'On weekends I visit exhibitions, and on weekdays I look for good coffee.';

const PROFILE_DETAILS: Record<number, { types: string[]; styles: string[]; times: string[]; qa: { q: string; a: string }[] }> = {
  1: { types: ['대화가 잘 통하는 사람', '차분한 사람'], styles: ['카페', '전시', '산책'], times: ['주말 오후', '평일 저녁'], qa: [{ q: '요즘 뭐가 제일 즐거우세요?', a: '주말 전시를 보고, 평일엔 좋은 커피를 찾으러 다니는 시간이 가장 즐거워요.' }, { q: '어떤 사람과 오래 만나고 싶어요?', a: '이야기가 자연스럽게 이어지는 사람과 오래 만나고 싶어요.' }, { q: '편한 만남은 어떤 모습인가요?', a: '서로 편하게, 솔직하게 이야기 나누는 만남이면 좋겠어요.' }] },
  2: { types: ['대화가 잘 통하는 사람', '유머 있는 사람'], styles: ['산책', '카페'], times: ['주말 오후', '평일 저녁'], qa: [{ q: '요즘 뭐가 제일 즐거우세요?', a: '산책하면서 대화 나누는 시간이 가장 좋아요.' }, { q: '어떤 사람과 오래 만나고 싶어요?', a: '같이 걸으면서도 편한 사람과 오래 만나고 싶어요.' }, { q: '편한 만남은 어떤 모습인가요?', a: '서두르지 않고 천천히 알아가는 만남이 편해요.' }] },
  3: { types: ['활동적인 사람', '대화가 잘 통하는 사람'], styles: ['카페', '식사'], times: ['주말 오후', '주말 저녁'], qa: [{ q: '요즘 뭐가 제일 즐거우세요?', a: '직접 만든 공간에서 사람 만나는 일이 가장 즐거워요.' }, { q: '어떤 사람과 오래 만나고 싶어요?', a: '새로운 이야기에 열린 마음으로 귀 기울이는 사람과 만나고 싶어요.' }, { q: '편한 만남은 어떤 모습인가요?', a: '맛있는 걸 먹으면서 편하게 웃을 수 있는 만남이 좋아요.' }] },
  4: { types: ['차분한 사람', '대화가 잘 통하는 사람'], styles: ['전시', '카페'], times: ['주말 오후', '평일 저녁'], qa: [{ q: '요즘 뭐가 제일 즐거우세요?', a: '전시와 독립영화를 보고, 조용한 대화를 나누는 시간이 좋아요.' }, { q: '어떤 사람과 오래 만나고 싶어요?', a: '조용히 오래 이야기할 수 있는 사람과 만나고 싶어요.' }, { q: '편한 만남은 어떤 모습인가요?', a: '말을 서두르지 않아도 되는, 여유 있는 만남이 편해요.' }] },
  5: { types: ['활동적인 사람', '차분한 사람'], styles: ['운동', '식사'], times: ['평일 저녁', '주말 저녁'], qa: [{ q: '요즘 뭐가 제일 즐거우세요?', a: '운동 후 먹는 저녁 시간이 제일 행복해요.' }, { q: '어떤 사람과 오래 만나고 싶어요?', a: '건강하게 자기 시간을 보내는 사람과 만나고 싶어요.' }, { q: '편한 만남은 어떤 모습인가요?', a: '가볍게 움직이고, 편하게 밥 먹는 만남이 좋아요.' }] },
  7: { types: ['대화가 잘 통하는 사람', '활동적인 사람'], styles: ['카페', '식사'], times: ['주말 오후', '주말 저녁'], qa: [{ q: '요즘 뭐가 제일 즐거우세요?', a: '새로 구운 빵 냄새 맡으며 하루를 시작하는 시간이 좋아요.' }, { q: '어떤 사람과 오래 만나고 싶어요?', a: '소소한 일상 이야기를 함께 나누는 사람과 만나고 싶어요.' }, { q: '편한 만남은 어떤 모습인가요?', a: '맛있는 빵과 커피를 앞에 두고 편하게 이야기하는 만남이 좋아요.' }] },
  6: { types: ['차분한 사람', '대화가 잘 통하는 사람'], styles: ['산책', '전시'], times: ['주말 오후', '평일 저녁'], qa: [{ q: '요즘 뭐가 제일 즐거우세요?', a: '그림 그리고, 동네를 산책하는 일상이 가장 좋아요.' }, { q: '어떤 사람과 오래 만나고 싶어요?', a: '서로의 일상을 궁금해하는 사람과 만나고 싶어요.' }, { q: '편한 만남은 어떤 모습인가요?', a: '천천히 걸으면서 그림 같은 이야기를 나누는 만남이 편해요.' }] },
  8: { types: ['유머 있는 사람', '대화가 잘 통하는 사람'], styles: ['카페', '식사'], times: ['평일 저녁', '주말 저녁'], qa: [{ q: '요즘 뭐가 제일 즐거우세요?', a: '재밌는 이야기를 듣고, 많이 웃는 시간이 가장 즐거워요.' }, { q: '어떤 사람과 오래 만나고 싶어요?', a: '함께 있으면 웃음이 많아지는 사람과 만나고 싶어요.' }, { q: '편한 만남은 어떤 모습인가요?', a: '긴장하지 않고 편하게 웃을 수 있는 만남이 좋아요.' }] },
  9: { types: ['차분한 사람', '대화가 잘 통하는 사람'], styles: ['산책', '전시'], times: ['주말 오후', '평일 저녁'], qa: [{ q: '요즘 뭐가 제일 즐거우세요?', a: '동네 골목을 걷다 보면 생기는 이야기가 가장 즐거워요.' }, { q: '어떤 사람과 오래 만나고 싶어요?', a: '골목처럼, 천천히 알아갈수록 매력이 있는 사람과 만나고 싶어요.' }, { q: '편한 만남은 어떤 모습인가요?', a: '조용히 걸으면서 편하게 이야기 나누는 만남이 좋아요.' }] },
  10: { types: ['차분한 사람', '대화가 잘 통하는 사람'], styles: ['카페', '전시'], times: ['주말 오후', '평일 저녁'], qa: [{ q: '요즘 뭐가 제일 즐거우세요?', a: '카페에서 책 읽고, 가끔 공연 보러 가는 시간이 좋아요.' }, { q: '어떤 사람과 오래 만나고 싶어요?', a: '책이나 공연 이야기를 함께 나눌 수 있는 사람과 만나고 싶어요.' }, { q: '편한 만남은 어떤 모습인가요?', a: '조용한 카페에서 차분하게 이야기 나누는 만남이 편해요.' }] },
  11: { types: ['대화가 잘 통하는 사람', '차분한 사람'], styles: ['산책', '카페'], times: ['평일 저녁', '주말 오후'], qa: [{ q: '요즘 뭐가 제일 즐거우세요?', a: '좋은 장면을 찾는 것처럼, 좋은 대화를 찾는 시간이 즐거워요.' }, { q: '어떤 사람과 오래 만나고 싶어요?', a: '이야기를 끝까지 들어주는 사람과 만나고 싶어요.' }, { q: '편한 만남은 어떤 모습인가요?', a: '서로에게 집중할 수 있는, 차분한 만남이 좋아요.' }] },
  12: { types: ['차분한 사람', '대화가 잘 통하는 사람'], styles: ['산책', '카페'], times: ['주말 오후', '평일 저녁'], qa: [{ q: '요즘 뭐가 제일 즐거우세요?', a: '꽃처럼, 천천히 알아가는 만남을 상상하는 시간이 좋아요.' }, { q: '어떤 사람과 오래 만나고 싶어요?', a: '서로를 천천히 알아가려는 마음이 있는 사람과 만나고 싶어요.' }, { q: '편한 만남은 어떤 모습인가요?', a: '서두르지 않고, 편안하게 걷는 만남이 좋아요.' }] },
};

function Toast({ text }: { text: string }) {
  if (!text) return null;
  return <div role="status" aria-live="polite" className="absolute left-4 right-4 bottom-[92px] z-50 flex items-center gap-3 rounded-2xl border-2 border-white/25 bg-[#1A1A1A] px-5 py-4 text-[15px] font-black leading-snug text-[#FFFFFF] shadow-2xl"><span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#FFFFFF] text-[#1A1A1A]"><Check size={17} strokeWidth={3} /></span><span>{text}</span></div>;
}
function DarkModal({ title, children, onClose, closeLabel = '닫기' }: { title: string; children: React.ReactNode; onClose: () => void; closeLabel?: string }) {
  return (
    <div className="absolute inset-0 z-[60] flex items-end justify-center bg-[rgba(0,0,0,0.6)] p-4 pb-6" role="dialog" aria-modal="true" aria-label={title} onClick={onClose}>
      <div className="w-full max-w-[380px] rounded-[24px] border-2 border-white/25 bg-[#1A1A1A] p-5 text-[#FFFFFF] shadow-2xl" onClick={e => e.stopPropagation()}>
        <h3 className="text-[19px] font-black leading-tight text-[#FFFFFF]">{title}</h3>
        <div className="mt-3 text-[15px] leading-relaxed text-[#FFFFFF]">{children}</div>
        <button onClick={onClose} className="mt-5 w-full rounded-xl border-2 border-white/40 bg-transparent py-3 text-[15px] font-black text-[#FFFFFF]">{closeLabel}</button>
      </div>
    </div>
  );
}
function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return <button onClick={onClick} className={`shrink-0 rounded-full px-3.5 py-2 text-[13px] font-bold transition ${active ? 'border-2 border-[#E85D3F] bg-[#E85D3F] text-white' : 'select-card'}`}>{children}</button>;
}
function SectionTitle({ kicker, title, sub }: { kicker: string; title: string; sub?: string }) {
  return <div><p className="text-[11px] font-black tracking-[0.16em] text-[#E85D3F]">{kicker}</p><h2 className="mt-1 text-[24px] font-black leading-tight tracking-tight">{title}</h2>{sub && <p className="mt-1 text-[13px] leading-relaxed text-[var(--muted)]">{sub}</p>}</div>;
}

export default function App() {
  const [stage, setStage] = useState<'login' | 'onboarding' | 'ideal' | 'main'>('login');
  const [loginMethod, setLoginMethod] = useState<'kakao' | 'phone' | 'guest' | null>(null);
  const [kakaoModalOpen, setKakaoModalOpen] = useState(false);
  const [kakaoKey, setKakaoKey] = useState('');
  const [kakaoRedirect, setKakaoRedirect] = useState(() => (typeof window !== 'undefined' && window.location.origin ? `${window.location.origin}/auth/kakao/callback` : 'https://example.com/auth/kakao/callback'));
  const [kakaoProfile, setKakaoProfile] = useState<{ nickname: string; email: string; image: string } | null>(null);
  const [kakaoDemoUsed, setKakaoDemoUsed] = useState(false);
  const [kakaoSettingsId, setKakaoSettingsId] = useState<string | null>(null);
  const [kakaoSaving, setKakaoSaving] = useState(false);
  const [kakaoSettingsMessage, setKakaoSettingsMessage] = useState('아직 저장된 카카오 설정이 없어요. 데모 모드로도 시작할 수 있어요.');
  const kakaoStatus = kakaoKey.trim() ? '연동준비됨' : kakaoDemoUsed ? '데모모드' : '미설정';
  const kakaoOAuthUrl = kakaoKey.trim() ? `https://kauth.kakao.com/oauth/authorize?client_id=${encodeURIComponent(kakaoKey.trim())}&redirect_uri=${encodeURIComponent(kakaoRedirect.trim())}&response_type=code` : '';
  const [onStep, setOnStep] = useState(0);
  const [phone, setPhone] = useState('');
  const [codeSent, setCodeSent] = useState(false);
  const [code, setCode] = useState('');
  const [phoneDone, setPhoneDone] = useState(false);
  const [nationality, setNationality] = useState<Nationality | null>(null);
  const [foreignCountry, setForeignCountry] = useState('미국');
  const [uiLang, setUiLang] = useState<UiLang>('ko');
  const [genderLocked, setGenderLocked] = useState(false);
  const [myGender, setMyGender] = useState<MyGender>('남성');
  const [desiredGender, setDesiredGender] = useState<DesiredGender>('여성');
  const [verify, setVerify] = useState<VerifyType>('business');
  const [uploaded, setUploaded] = useState(false);
  const [faceUploaded, setFaceUploaded] = useState(false);
  const [faceVerified, setFaceVerified] = useState(false);
  const [matchPreview, setMatchPreview] = useState<'mine' | 'other'>('mine');
  const [tab, setTab] = useState<Tab>('home');
  const [view, setView] = useState<View>('main');
  const [toast, setToast] = useState('');
  const [ageRange, setAgeRange] = useState('28–33세');
  const [areas, setAreas] = useState<string[]>(['성수', '연남']);
  const [types, setTypes] = useState<string[]>(['대화가 잘 통하는 사람', '차분한 사람']);
  const [styles, setStyles] = useState<string[]>(['카페', '산책']);
  const [times, setTimes] = useState<string[]>(['주말 오후']);
  const [answers, setAnswers] = useState(['요즘 가장 즐겁게 하는 일은 주말에 동네 산책하기예요.', '상대와 오래 이야기할 수 있는 사람과 만나고 싶어요.', '서로 편하게, 솔직하게 이야기 나누는 만남이면 좋겠어요.']);
  const [applied, setApplied] = useState<number[]>([]);
  const [requestStatus, setRequestStatus] = useState<'waiting' | 'accepted' | 'reschedule' | 'declined'>('waiting');
  const [rescheduleChoice, setRescheduleChoice] = useState('');
  const [cancelsLeft, setCancelsLeft] = useState(3);
  const [cancelledIds, setCancelledIds] = useState<number[]>([]);
  const [feedback, setFeedback] = useState('');
  const [afterCount, setAfterCount] = useState(2);
  const [reportText, setReportText] = useState('');
  const [reportDone, setReportDone] = useState(false);
  const [reportTargetId, setReportTargetId] = useState<number | null>(null);
  const [reportReasons, setReportReasons] = useState<string[]>([]);
  const [reportReturnToProfile, setReportReturnToProfile] = useState(false);
  const [reportReturnTab, setReportReturnTab] = useState<Tab>('my');
  const [deckIndex, setDeckIndex] = useState(0);
  const [passedIds, setPassedIds] = useState<number[]>([]);
  const [dragX, setDragX] = useState(0);
  const [dragging, setDragging] = useState(false);
  const [exiting, setExiting] = useState<'left' | 'right' | null>(null);
  const dragStartX = useRef(0);
  const dragMoved = useRef(false);
  const [shareDone, setShareDone] = useState(false);
  const [dressColor, setDressColor] = useState('blue');
  const [dressItem, setDressItem] = useState('coffee');
  const [dressCustomColor, setDressCustomColor] = useState('');
  const [dressCustomItem, setDressCustomItem] = useState('');
  const [dressCustomSaved, setDressCustomSaved] = useState(false);
  const [dressColorError, setDressColorError] = useState('');
  const [dressItemError, setDressItemError] = useState('');
  const [dressConfirmed, setDressConfirmed] = useState(false);
  const [dressStatus, setDressStatus] = useState<'editing' | 'proposed' | 'confirmed'>('editing');
  const [dressChangesLeft, setDressChangesLeft] = useState(1);
  const [dressPartnerNote, setDressPartnerNote] = useState('');
  const [metIds, setMetIds] = useState<number[]>([]);
  const [arrivalOn, setArrivalOn] = useState(true);
  const [proximityOn, setProximityOn] = useState(true);
  const [proximityDistance, setProximityDistance] = useState<number | null>(null);
  const [arrivalSentIds, setArrivalSentIds] = useState<number[]>([]);
  const [cancelTargetId, setCancelTargetId] = useState<number | null>(null);
  const [meetingCheckId, setMeetingCheckId] = useState<number | null>(null);
  const [noshowForId, setNoshowForId] = useState<number | null>(null);
  const [noshowReason, setNoshowReason] = useState('');
  const [noshowNote, setNoshowNote] = useState('');
  const [noshowSubmitted, setNoshowSubmitted] = useState(false);
  const [noshowCount, setNoshowCount] = useState(0);
  const [excludedCount, setExcludedCount] = useState(0);
  const [checkinId, setCheckinId] = useState<number | null>(null);
  const [checkinOpen, setCheckinOpen] = useState(false);
  const [checkinStage, setCheckinStage] = useState<CheckinStage>('permission');
  const [verifiedIds, setVerifiedIds] = useState<number[]>([]);
  const [disputeMode, setDisputeMode] = useState(false);
  const [reportKind, setReportKind] = useState<'general' | 'noshow'>('general');
  const shareRef = useRef<HTMLTextAreaElement>(null);
  // Local-session preview only: nothing is written to storage or a server.
  // Reloading this page starts a fresh local session.
  const [showDevData, setShowDevData] = useState(false);
  const [backendStatus, setBackendStatus] = useState<'disconnected' | 'checking' | 'connected' | 'failed'>('disconnected');
  const [backendBusy, setBackendBusy] = useState(false);
  const [backendMessage, setBackendMessage] = useState('아직 연결을 확인하지 않았어요. 데모 모드로도 모든 화면을 볼 수 있어요.');
  const [backendLastChecked, setBackendLastChecked] = useState('');
  const [backendTables, setBackendTables] = useState<{ name: string; status: string; detail: string }[]>([]);
  const [showBackendSnippet, setShowBackendSnippet] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [submittedReports, setSubmittedReports] = useState<{ id: number; target: string; reasons: string[]; detail: string; at: string }[]>([]);
  const [localSavedAt, setLocalSavedAt] = useState(() => new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }));
  const devPreviewRef = useRef<HTMLTextAreaElement>(null);
  const [myIntro, setMyIntro] = useState(MY_INTRO_DEFAULT);
  const [myIntroMode, setMyIntroMode] = useState<IntroMode>('translated');
  const [myPageIntroMode, setMyPageIntroMode] = useState<IntroMode>('translated');
  const [expandedOriginals, setExpandedOriginals] = useState<Record<number, boolean>>({});
  const [selectedProfileId, setSelectedProfileId] = useState<number | null>(null);
  const [detailIntroTab, setDetailIntroTab] = useState<IntroMode>('translated');
  const [detailDate, setDetailDate] = useState('');
  const [detailReturnTab, setDetailReturnTab] = useState<Tab>('recommend');
  const selectedProfile = PROFILES.find(p => p.id === selectedProfileId) || null;
  const myIntroTranslated = myIntro.trim() === MY_INTRO_DEFAULT ? MY_INTRO_EN : 'Your introduction will be shown here in your match’s language, translated automatically.';
  const myIntroOriginalLabel = '원문 · 한국어';
  const toggleOriginal = (id: number) => setExpandedOriginals(prev => ({ ...prev, [id]: !prev[id] }));
  const openProfile = (p: Profile, returnTab: Tab = 'recommend') => { setSelectedProfileId(p.id); setDetailIntroTab('translated'); setDetailDate(p.dates[0] || ''); setDetailReturnTab(returnTab); setView('profile'); };
  const openProfileById = (id: number, returnTab: Tab = 'recommend') => { const p = PROFILES.find(x => x.id === id); if (p) openProfile(p, returnTab); };
  const closeProfile = () => { setView('main'); setTab(detailReturnTab); };
  const applyFromDetail = (p: Profile) => {
    if (applied.includes(p.id)) { closeProfile(); return; }
    setApplied(prev => prev.includes(p.id) ? prev : [...prev, p.id]);
    setTab(detailReturnTab); setView('main');
    showToast('데이트 신청이 전송됐어요 · 상대 응답 대기 24시간');
  };

  const openReport = (targetId: number | null, opts?: { fromProfile?: boolean; returnTab?: Tab; preselect?: string }) => {
    setReportTargetId(targetId);
    setReportReasons(opts?.preselect ? [opts.preselect] : []);
    setReportText('');
    setReportDone(false);
    setReportReturnToProfile(Boolean(opts?.fromProfile));
    setReportReturnTab(opts?.returnTab || 'my');
    setView('report');
  };
  const closeReport = () => {
    if (reportReturnToProfile) { setView('profile'); return; }
    setView('main'); setTab(reportReturnTab);
  };
  const submitReport = () => {
    if (reportReasons.length === 0) { showToast('신고 사유를 하나 이상 선택해 주세요'); return; }
    setReportDone(true);
    const targetName = reportTarget ? `${reportTarget.name} · ${reportTarget.age}세` : '신고 대상 선택 전';
    setSubmittedReports(prev => [...prev, { id: Date.now(), target: targetName, reasons: [...reportReasons], detail: reportText, at: new Date().toLocaleString('ko-KR') }]);
    const returnToProfile = reportReturnToProfile;
    const returnTab = reportReturnTab;
    setReportReasons([]); setReportText('');
    if (returnToProfile) setView('profile'); else { setView('main'); setTab(returnTab); }
    showToast('신고가 이 화면에 임시로 기록됐어요 · 서버로 보내지 않아요');
  };
  const resetDeck = () => { setDeckIndex(0); setPassedIds([]); setDragX(0); setDragging(false); setExiting(null); dragMoved.current = false; };
  const swipeDeck = (dir: 'left' | 'right', p?: Profile) => {
    if (exiting || !p) return;
    setExiting(dir);
    setDragX(dir === 'left' ? -360 : 360);
    window.setTimeout(() => {
      if (dir === 'right') {
        if (!applied.includes(p.id)) { setApplied(prev => [...prev, p.id]); showToast('데이트 신청이 전송됐어요 · 상대 응답 대기 24시간'); }
      } else {
        setPassedIds(prev => prev.includes(p.id) ? prev : [...prev, p.id]);
        showToast('다음에 볼 사람으로 남겨뒀어요');
      }
      setDeckIndex(prev => prev + 1); setDragX(0); setDragging(false); setExiting(null); dragMoved.current = false;
    }, 260);
  };

  const profileGenderLabel = myGender;
  const profilePreview = `상대에게 보이는 내 프로필: ${profileGenderLabel} · 20대 후반`;
  const authMethodLabel = '한국 휴대폰 인증';
  const genderLockMessage = '성별은 한 번 정하면 수정할 수 없어요';
  const genderLockNote = '본인인증 결과로 확정되며, 한 번 정하면 수정할 수 없어요';
  const isForeign = nationality === 'foreigner';
  const langTrans = uiLang === 'ko' ? null : TRANSLATED[uiLang];
  const bi = (ko: string, key: 'dateRequest' | 'todayRec' | 'header' | 'accept') => (isForeign && langTrans ? `${ko} / ${langTrans[key]}` : ko);
  const pickForeignCountry = (country: string) => {
    const found = FOREIGN_COUNTRIES.find(c => c.id === country);
    setForeignCountry(country);
    if (found) setUiLang(found.lang);
  };

  const showToast = (t: string) => { setToast(t); setTimeout(() => setToast(''), 2600); };
  const saveKakaoSettings = async () => {
    setKakaoSaving(true);
    try {
      const value = { restApiKey: kakaoKey.trim(), redirectUri: kakaoRedirect.trim(), updatedAt: new Date().toISOString() };
      if (kakaoSettingsId) {
        await callRecordsApi("records.replace", { collection: 'kakao_settings', id: kakaoSettingsId, value });
      } else {
        const created = await callRecordsApi("records.create", { collection: 'kakao_settings', value, idempotency_key: `kakao-settings-${Date.now()}` }) as { id?: string } | null;
        if (created && created.id) setKakaoSettingsId(created.id);
      }
      setKakaoSettingsMessage(kakaoKey.trim() ? '카카오 설정이 저장됐어요 · 연동준비됨' : '카카오 설정이 저장됐어요 · 데모 모드로 시작할 수 있어요');
      showToast('카카오 설정이 저장됐어요');
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      setKakaoSettingsMessage(`카카오 설정 저장에 실패했어요 · ${msg}`);
      showToast('카카오 설정 저장에 실패했어요 · 다시 시도해 주세요');
    } finally { setKakaoSaving(false); }
  };
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await callRecordsApi("records.list", { collection: 'kakao_settings', limit: 1 }) as { records?: { id: string; value: { restApiKey?: string; redirectUri?: string } }[] } | null;
        const first = data?.records?.[0];
        if (!cancelled && first) {
          setKakaoSettingsId(first.id);
          if (typeof first.value.restApiKey === 'string') setKakaoKey(first.value.restApiKey);
          if (typeof first.value.redirectUri === 'string' && first.value.redirectUri) setKakaoRedirect(first.value.redirectUri);
          setKakaoSettingsMessage(first.value.restApiKey ? '저장된 카카오 설정이 있어요 · 연동준비됨' : '저장된 카카오 설정이 있어요 · 데모 모드');
        }
      } catch { /* 저장된 설정이 없으면 데모 모드로 시작해요 */ }
    })();
    return () => { cancelled = true; };
  }, []);
  const startKakaoDemo = () => {
    setKakaoProfile({ nickname: '카카오 사용자', email: 'ka***@kakao.com', image: '카' });
    setKakaoDemoUsed(true);
    setLoginMethod('kakao');
    setKakaoModalOpen(false);
    setStage('onboarding');
    setOnStep(1);
    showToast('카카오 데모 프로필을 받았어요 · 전화번호 인증으로 이동해요');
  };
  const startPhoneFlow = () => { setLoginMethod('phone'); setKakaoModalOpen(false); setStage('onboarding'); setOnStep(0); showToast('전화번호로 시작해요'); };
  const startGuestFlow = () => { setLoginMethod('guest'); setKakaoModalOpen(false); setStage('main'); setTab('recommend'); setMatchPreview('mine'); showToast('게스트로 둘러보고 있어요 · 신청은 로그인 후에 할 수 있어요'); };
  const callRecordsApi = async (action: string, args: Record<string, unknown>) => {
    const res = await fetch("actions", { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action, args }) });
    const json = await res.json().catch(() => ({} as { error?: unknown; data?: unknown }));
    if (!res.ok || (json as { error?: unknown }).error) throw new Error(typeof (json as { error?: unknown }).error === 'string' ? (json as { error: string }).error : `요청 실패 (${res.status})`);
    return (json as { data?: unknown }).data;
  };
  const testBackendConnection = async () => {
    setBackendStatus('checking'); setBackendBusy(true); setBackendMessage('연결을 확인하고 있어요…');
    try {
      await callRecordsApi("records.list", { collection: 'users', limit: 1 });
      const at = new Date().toLocaleString('ko-KR');
      setBackendLastChecked(at); setBackendStatus('connected'); setBackendMessage('연결 성공 - 서버에 닿았어요 · users 컬렉션이 응답했어요');
      showToast('백엔드 연결 성공 - 서버에 닿았어요');
    } catch (e) {
      const at = new Date().toLocaleString('ko-KR');
      setBackendLastChecked(at); setBackendStatus('failed'); setBackendMessage('연결 실패 - 서버에 닿지 않았어요. 아래 체크리스트를 확인해 보세요.');
      showToast('백엔드 연결에 실패했어요 · 데모 모드로 계속 볼 수 있어요');
    } finally { setBackendBusy(false); }
  };
  const checkBackendTables = async () => {
    setBackendStatus('checking'); setBackendBusy(true); setBackendMessage('6개 컬렉션을 하나씩 확인하고 있어요…');
    const names = ['users', 'profiles', 'date_requests', 'calendar_events', 'reports', 'dress_codes'];
    const results: { name: string; status: string; detail: string }[] = [];
    for (const name of names) {
      try { await callRecordsApi("records.list", { collection: name, limit: 1 }); results.push({ name, status: 'OK', detail: '응답했어요' }); }
      catch (e) { const msg = e instanceof Error ? e.message : String(e); results.push({ name, status: msg.includes('not found') || msg.includes('없음') ? '없음' : '권한없음', detail: msg }); }
    }
    setBackendTables(results); setBackendLastChecked(new Date().toLocaleString('ko-KR'));
    const okCount = results.filter(r => r.status === 'OK').length;
    if (okCount === names.length) { setBackendStatus('connected'); setBackendMessage(`연결 성공 - 서버에 닿았어요 · ${okCount}/6개 컬렉션이 응답했어요`); }
    else { setBackendStatus('failed'); setBackendMessage(`일부 컬렉션만 응답했어요 · ${okCount}/6개 OK`); }
    setBackendBusy(false);
  };
  const disconnectBackend = () => { setBackendStatus('disconnected'); setBackendBusy(false); setBackendTables([]); setBackendMessage('연결을 해제했어요 · 데모 모드로 계속 사용할 수 있어요'); showToast('백엔드 연결을 해제했어요'); };
  const copyDevPreview = () => { if (devPreviewRef.current) { devPreviewRef.current.select(); document.execCommand('copy'); } showToast('로컬 미리보기 내용이 복사됐어요'); };
  const resetLocalData = () => {
    setStage('login'); setLoginMethod(null); setKakaoProfile(null); setKakaoDemoUsed(false); setKakaoModalOpen(false); setOnStep(0); setPhone(''); setCodeSent(false); setCode(''); setPhoneDone(false); setNationality(null); setForeignCountry('미국'); setUiLang('ko'); setMyGender('남성'); setDesiredGender('여성'); setVerify('business'); setUploaded(false); setFaceUploaded(false); setFaceVerified(false); setMatchPreview('mine'); setTab('home'); setView('main'); setAgeRange('28–33세'); setAreas(['성수', '연남']); setTypes(['대화가 잘 통하는 사람', '차분한 사람']); setStyles(['카페', '산책']); setTimes(['주말 오후']); setAnswers(['요즘 가장 즐겁게 하는 일은 주말에 동네 산책하기예요.', '상대와 오래 이야기할 수 있는 사람과 만나고 싶어요.', '서로 편하게, 솔직하게 이야기 나누는 만남이면 좋겠어요.']); setApplied([]); setRequestStatus('waiting'); setRescheduleChoice(''); setCancelsLeft(3); setCancelledIds([]); setFeedback(''); setAfterCount(2); setReportText(''); setReportDone(false); setReportTargetId(null); setReportReasons([]); setSubmittedReports([]); setDeckIndex(0); setPassedIds([]); setShareDone(false); setDressColor('blue'); setDressItem('coffee'); setDressCustomColor(''); setDressCustomItem(''); setDressCustomSaved(false); setDressConfirmed(false); setDressStatus('editing'); setDressChangesLeft(1); setDressPartnerNote(''); setMetIds([]); setProximityOn(true); setProximityDistance(null); setArrivalSentIds([]); setVerifiedIds([]); setMyIntro(MY_INTRO_DEFAULT); setSelectedProfileId(null); setDetailDate(''); setShowDevData(false); setConfirmReset(false);
    setLocalSavedAt(new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }));
    showToast('이 화면의 로컬 입력이 초기화됐어요');
  };
  useEffect(() => { setLocalSavedAt(new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })); }, [nationality, phoneDone, myGender, desiredGender, verify, uiLang, myIntro, applied, deckIndex, dressColor, dressCustomColor, dressItem, dressCustomItem, dressStatus, submittedReports, cancelsLeft]);
  const buzz = (pattern: number | number[]) => { try { if (typeof navigator !== 'undefined' && 'vibrate' in navigator) navigator.vibrate(pattern); } catch { /* 진동을 지원하지 않는 기기에서는 시각 알림만 보여줘요 */ } };
  const dressCustomColorText = dressCustomColor.trim();
  const dressCustomItemText = dressCustomItem.trim();
  const dressColorLabel = dressColor === 'custom' ? (dressCustomColorText ? `직접 입력 - ${dressCustomColorText}` : '기타 - 직접 적기') : (DRESS_COLORS.find(c => c.id === dressColor) || DRESS_COLORS[0]).label;
  const dressColorDesc = dressColor === 'custom' ? (dressCustomColorText ? `${dressCustomColorText} 상의` : '직접 입력 상의') : (DRESS_COLORS.find(c => c.id === dressColor) || DRESS_COLORS[0]).desc;
  const dressItemLabel = dressItem === 'custom' ? (dressCustomItemText ? `직접 입력 - ${dressCustomItemText}` : '기타 - 직접 적기') : (DRESS_ITEMS.find(i => i.id === dressItem) || DRESS_ITEMS[0]).label;
  const dressItemShort = dressItem === 'custom' ? (dressCustomItemText || '직접 입력') : (DRESS_ITEMS.find(i => i.id === dressItem) || DRESS_ITEMS[0]).short;
  const dressFull = `${dressColorDesc} + ${dressItemLabel}`;
  const dressColorPlain = dressColor === 'custom' ? (dressCustomColorText || '직접 입력') : (DRESS_COLORS.find(c => c.id === dressColor) || DRESS_COLORS[0]).label;
  const dressItemPlain = dressItem === 'custom' ? (dressCustomItemText || '직접 입력') : (DRESS_ITEMS.find(i => i.id === dressItem) || DRESS_ITEMS[0]).short;
  const dressShort = `드레스코드: ${dressColorPlain} + ${dressItemPlain}`;
  const dressHasSavedCustom = dressCustomSaved || (dressColor === 'custom' && Boolean(dressCustomColorText)) || (dressItem === 'custom' && Boolean(dressCustomItemText));
  const dressCustomMissing = (dressColor === 'custom' && !dressCustomColorText) || (dressItem === 'custom' && !dressCustomItemText);
  const saveDressCustom = () => {
    if (dressCustomMissing) {
      if (dressColor === 'custom' && !dressCustomColorText) setDressColorError('직접 입력할 내용을 적어주세요');
      if (dressItem === 'custom' && !dressCustomItemText) setDressItemError('직접 입력할 내용을 적어주세요');
      showToast('직접 입력할 내용을 적어주세요');
      return;
    }
    setDressCustomSaved(true); setDressStatus('editing');
    showToast('직접 입력한 드레스코드가 이 화면에 임시로 반영됐어요');
  };
  const saveDressColorCustom = () => {
    if (dressColor === 'custom' && !dressCustomColorText) { setDressColorError('직접 입력할 내용을 적어주세요'); showToast('직접 입력할 내용을 적어주세요'); return; }
    setDressColorError('');
    setDressCustomSaved(true); setDressStatus('editing');
    showToast('직접 입력한 드레스코드가 이 화면에 임시로 반영됐어요');
  };
  const saveDressItemCustom = () => {
    if (dressItem === 'custom' && !dressCustomItemText) { setDressItemError('직접 입력할 내용을 적어주세요'); showToast('직접 입력할 내용을 적어주세요'); return; }
    setDressItemError('');
    setDressCustomSaved(true); setDressStatus('editing');
    showToast('직접 입력한 드레스코드가 이 화면에 임시로 반영됐어요');
  };
  const proposeDress = () => { if (dressCustomMissing) { if (dressColor === 'custom' && !dressCustomColorText) setDressColorError('직접 입력할 내용을 적어주세요'); if (dressItem === 'custom' && !dressCustomItemText) setDressItemError('직접 입력할 내용을 적어주세요'); showToast('직접 입력할 내용을 적어주세요'); return; } setDressStatus('proposed'); setDressPartnerNote(''); showToast('드레스코드를 서연 님에게 제안했어요'); };
  const partnerLikeDress = () => { setDressStatus('confirmed'); setDressConfirmed(true); showToast('드레스코드가 확정됐어요'); };
  const partnerChangeDress = () => {
    if (dressChangesLeft <= 0) { showToast('변경은 1회만 가능해요'); return; }
    setDressChangesLeft(0); setDressStatus('editing'); setDressConfirmed(false);
    setDressPartnerNote('서연 님이 다른 걸로 바꿔달라고 했어요. 색깔과 소품을 다시 골라 보세요.');
    showToast('상대가 변경을 요청했어요 · 변경 가능 0회 남음');
  };
  // In-memory “tables” for the on-screen developer preview. They are rebuilt
  // from the current session state and are never sent anywhere.
  const localTables = useMemo(() => ({
    users: [{ id: 'local-me', nationality, foreignCountry: isForeign ? foreignCountry : null, phoneVerified: phoneDone, genderLocked, myGender, desiredGender, age: 28, verifyType: verify, faceVerified, uiLang, myIntro, ideal: { ageRange, areas, types, styles, times, answers } }],
    profiles: PROFILES.map(p => ({ id: p.id, name: p.name, age: p.age, area: p.area, verified: p.verified, badge: p.badge })),
    date_requests: applied.map(id => ({ profileId: id, status: 'waiting', selectedDate: detailDate || null })),
    calendar_events: [{ id: 101, date: '11/19 수 19:00', place: '성수 · 카페 온', partner: '지우 · 29', cancelled: cancelledIds.includes(101), met: metIds.includes(101), verified: verifiedIds.includes(101) }, { id: 102, date: '11/21 금 19:30', place: '연남 · 산책 후 카페', partner: '서연 · 27', cancelled: cancelledIds.includes(102), met: metIds.includes(102), verified: verifiedIds.includes(102) }, { id: 103, date: '11/25 수 19:00', place: '홍대 · 전시 관람', partner: '하윤 · 28', cancelled: cancelledIds.includes(103), met: metIds.includes(103), verified: verifiedIds.includes(103) }],
    reports: submittedReports,
    dress_codes: [{ partner: '서연', color: dressColor, customColor: dressCustomColor, item: dressItem, customItem: dressCustomItem, status: dressStatus, confirmed: dressConfirmed, preview: `${dressColorDesc} + ${dressItemLabel}` }],
    session: { scope: '이 화면 세션 전용 · 새로고침하면 초기화', savedAt: localSavedAt, deckIndex, passedIds, cancelsLeft },
  }), [nationality, foreignCountry, isForeign, phoneDone, genderLocked, myGender, desiredGender, verify, faceVerified, uiLang, myIntro, ageRange, areas, types, styles, times, answers, applied, detailDate, cancelledIds, metIds, verifiedIds, submittedReports, dressColor, dressCustomColor, dressItem, dressCustomItem, dressStatus, dressConfirmed, dressColorDesc, dressItemLabel, localSavedAt, deckIndex, passedIds, cancelsLeft]);
  const localTablesJson = useMemo(() => JSON.stringify(localTables, null, 2), [localTables]);
  const sendArrivalPush = (id: number) => {
    void id;
    if (!arrivalSentIds.includes(id)) setArrivalSentIds([...arrivalSentIds, id]);
    buzz([120, 60, 120]);
    showToast('도착했어요 푸시를 상대에게 보냈어요');
  };
  const openCheckin = (id: number) => { setCheckinId(id); setCheckinStage('permission'); setCheckinOpen(true); };
  const closeCheckin = () => { setCheckinOpen(false); setCheckinId(null); };
  const startArrival = (id: number) => { sendArrivalPush(id); openCheckin(id); };
  const allowOnce = () => {
    if (checkinId === null) return;
    const id = checkinId;
    setCheckinStage('checking');
    setTimeout(() => {
      setCheckinStage('location');
      if (!verifiedIds.includes(id)) setVerifiedIds(prev => [...prev, id]);
      if (!metIds.includes(id)) setMetIds(prev => [...prev, id]);
      buzz([120, 60, 120]);
    }, 1400);
  };
  const confirmMutualMet = () => {
    if (checkinId === null) return;
    const id = checkinId;
    setCheckinStage('verified');
    if (!verifiedIds.includes(id)) setVerifiedIds(prev => [...prev, id]);
    if (!metIds.includes(id)) setMetIds(prev => [...prev, id]);
    buzz([120, 60, 120]);
    showToast('만남 인증이 완료됐어요');
  };
  const checkinPartnerName = checkinId === 102 ? '서연' : checkinId === 103 ? '하윤' : '지우';
  const advanceProximity = () => { buzz([120, 60, 120]); showToast('도착 알림 미리보기예요 · 상대가 도착하면 푸시 알림 + 진동으로 알려드려요'); };
  const confirmCancel = () => {
    if (cancelTargetId === null || cancelsLeft <= 0 || cancelledIds.includes(cancelTargetId)) { setCancelTargetId(null); return; }
    setCancelsLeft(cancelsLeft - 1); setCancelledIds([...cancelledIds, cancelTargetId]); setCancelTargetId(null); showToast('취소가 접수됐어요. 상대에게도 알려드렸어요.');
  };
  const toggle = (list: string[], v: string, set: (x: string[]) => void, max?: number) => {
    if (list.includes(v)) set(list.filter(x => x !== v));
    else if (!max || list.length < max) set([...list, v]);
    else showToast(`최대 ${max}개까지 선택할 수 있어요`);
  };
  const apply = (id: number) => {
    if (applied.includes(id)) return;
    setApplied([...applied, id]); showToast('데이트 신청이 전송됐어요');
  };
  const cancelAfter = (id: number) => {
    if (cancelsLeft <= 0 || cancelledIds.includes(id)) return;
    setCancelsLeft(cancelsLeft - 1); setCancelledIds([...cancelledIds, id]); showToast('취소가 접수됐어요. 상대에게도 알려드렸어요.');
  };
  const copyShare = () => {
    if (shareRef.current) { shareRef.current.select(); document.execCommand('copy'); }
    setShareDone(true); showToast('일정 내용이 복사됐어요');
  };

  const calendar = useMemo(() => {
    const first = new Date(2026, 10, 1).getDay(); const daysIn = 30;
    const cells: (number | null)[] = Array(first).fill(null);
    for (let d = 1; d <= daysIn; d++) cells.push(d);
    while (cells.length % 7) cells.push(null);
    return cells;
  }, []);
  const marked: Record<number, string> = { 19: '애프터', 21: '데이트 신청', 22: '애프터', 25: '예정', 28: '예정' };

  const upcoming = [
    { id: 101, date: '11/19 수 19:00', place: '성수 · 카페 온', partner: '지우 · 29', kind: '3차 애프터', status: '확정', color: '#E85D3F' },
    { id: 102, date: '11/21 금 19:30', place: '연남 · 산책 후 카페', partner: '서연 · 27', kind: '데이트 신청', status: '상대 응답 대기', color: '#E9A44A' },
    { id: 103, date: '11/25 수 19:00', place: '홍대 · 전시 관람', partner: '하윤 · 28', kind: '2차 애프터', status: '확정', color: '#6E9A7E' },
  ];

  const verifyCards: { id: VerifyType; title: string; desc: string; icon: string }[] = [
    { id: 'job', title: '직장인', desc: '회사 이메일로 소속 인증', icon: '💼' },
    { id: 'student', title: '학생', desc: '학교 이메일로 소속 인증', icon: '🎓' },
    { id: 'business', title: '자영업자', desc: '사업자등록증으로 인증', icon: '🏪' },
    { id: 'later', title: '나중에 할래요', desc: '인증 없이 시작하기', icon: '⏰' },
  ];
  const isVerified = verify !== 'later';
  const verifyLabel = verify === 'job' ? '직장 인증 완료' : verify === 'student' ? '학생 인증 완료' : verify === 'business' ? '사업자 인증 완료' : '미인증';
  const shownVerified = matchPreview === 'mine' ? isVerified : !isVerified;
  const visibleProfiles = PROFILES.filter(p => p.verified === shownVerified).slice(0, 6);
  const reportTarget = reportTargetId === null ? null : PROFILES.find(p => p.id === reportTargetId) || null;
  const deckTotal = visibleProfiles.length;
  const deckFinished = deckIndex >= deckTotal;
  const deckCurrent = deckFinished ? null : visibleProfiles[deckIndex];
  const deckRemaining = Math.max(0, deckTotal - deckIndex);

  return (
    <div data-safe-area-inset-root style={{boxSizing: 'border-box', paddingTop: 'var(--safe-area-inset-top)'}} className="min-h-[100dvh] w-full overflow-x-clip bg-[#EADFD5] sm:flex sm:items-center sm:justify-center sm:py-6">
      <div className="relative mx-auto flex h-[100dvh] w-full max-w-[430px] flex-col overflow-hidden bg-[var(--bg)] shadow-2xl sm:h-[880px] sm:max-h-[calc(100dvh-48px)] sm:rounded-[42px] sm:border-[10px] sm:border-[#2B2622]">
        {/* status bar */}
        <div className="flex items-center justify-between px-6 pt-3 text-[11px] font-bold text-[var(--muted)]"><span>9:41</span><span className="flex gap-1">● ● ●</span></div>
        <div className="mx-4 mt-2 flex items-center justify-between gap-2 rounded-full bg-[#1A1A1A] px-3.5 py-2 text-[11px] font-black text-white"><span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-[#7ED491]" />웹앱 MVP · 이 화면 세션에만 임시 저장</span><span className="shrink-0 text-white/80">{localSavedAt} 반영</span></div>
        <p className="px-6 pt-1.5 text-center text-[10px] font-bold text-[var(--muted)]">서버나 기기에 저장되지 않아요 · 새로고침하면 처음 상태로 돌아가요</p>

        <div className="relative flex-1 overflow-y-auto no-scrollbar">
          {stage === 'login' && (
            <div className="px-5 pb-8 pt-4">
              <div className="mt-10 text-center"><div className="mx-auto flex h-16 w-16 items-center justify-center rounded-[22px] bg-[var(--accent)] text-3xl shadow-lg shadow-orange-200">☕</div><h1 className="serif mt-5 text-[42px] font-black leading-none tracking-tight">애프터</h1><p className="mt-3 text-[15px] font-bold text-[var(--muted)]">채팅 없이, 만나서 알아가는 소개팅</p><p className="mx-auto mt-2 max-w-[290px] text-[12px] leading-relaxed text-[var(--muted)]">첫 만남은 데이트 신청, 2번째부터 애프터,<br />3번 만나면 연애 시작할지 결정해요.</p></div>
              <div className="mt-10 rounded-[24px] border border-[var(--line)] bg-[var(--surface)] p-5 shadow-sm">
                <p className="text-[12px] font-black tracking-wider text-[var(--muted)]">시작하기</p><h2 className="mt-2 text-[20px] font-black">어떻게 시작할까요?</h2>
                <button onClick={() => setKakaoModalOpen(true)} className="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-[#FEE500] py-4 text-[16px] font-black text-[#1A1A1A] shadow-sm"><span aria-hidden="true" className="relative flex h-6 w-6 items-center justify-center"><span className="absolute inset-0 rounded-full bg-[#1A1A1A]" style={{ clipPath: 'polygon(0 0, 100% 0, 100% 78%, 62% 78%, 50% 100%, 42% 78%, 0 78%)' }} /><span className="relative z-10 text-[11px] font-black text-[#FEE500]">:)</span></span>카카오로 시작하기</button>
                <p className="mt-2 text-center text-[12px] leading-relaxed text-[var(--muted)]">카카오 계정으로 간편하게 시작해요. 본인인증은 다음 단계에서 해요.</p>
                <button onClick={startPhoneFlow} className="mt-4 w-full rounded-2xl border-2 border-[var(--line)] bg-[var(--surface)] py-3.5 text-[15px] font-black">전화번호로 시작하기</button>
                <button onClick={startGuestFlow} className="mt-2 w-full rounded-2xl bg-[var(--bg)] py-3.5 text-[14px] font-bold text-[var(--muted)]">게스트로 둘러보기</button>
                {kakaoProfile && <p className="mt-3 rounded-xl bg-[var(--sage-bg)] p-3 text-center text-[12px] font-bold text-[#4F7A5D]">{kakaoProfile.nickname} 님 · 카카오 데모 프로필이 있어요 · 전화번호 인증으로 이어서 시작할 수 있어요</p>}
                <div className="mt-4 flex items-center justify-between rounded-xl bg-[var(--bg)] px-3 py-2.5 text-[11px] font-bold"><span>카카오 설정 상태</span><span className={`rounded-full px-2.5 py-1 text-[11px] font-black ${kakaoStatus === '연동준비됨' ? 'bg-[var(--sage-bg)] text-[#4F7A5D]' : kakaoStatus === '데모모드' ? 'bg-[#FFF6E6] text-[#9A6A1A]' : 'bg-white text-[var(--muted)]'}`}>{kakaoStatus}</span></div>
                <p className="mt-2 text-center text-[11px] leading-relaxed text-[var(--muted)]">카카오 키는 코드에 적지 않아요. 마이페이지 &gt; 백엔드 연결 &gt; 카카오 설정에서 저장해요.</p>
              </div>
              {kakaoModalOpen && (
                <div className="absolute inset-0 z-[70] flex items-end justify-center bg-[rgba(0,0,0,0.6)] p-4 pb-6 sm:items-center" role="dialog" aria-modal="true" aria-label="카카오 로그인 연결하기" onClick={() => setKakaoModalOpen(false)}>
                  <div className="max-h-[86dvh] w-full max-w-[420px] overflow-y-auto rounded-[24px] bg-[var(--surface)] p-5 shadow-2xl" onClick={e => e.stopPropagation()}>
                    <div className="flex items-start justify-between gap-2"><h3 className="text-[19px] font-black leading-tight">카카오 로그인 연결하기</h3><button onClick={() => setKakaoModalOpen(false)} className="shrink-0 rounded-full bg-[var(--bg)] px-3 py-1.5 text-[12px] font-black">닫기</button></div>
                    <p className="mt-1 text-[12px] leading-relaxed text-[var(--muted)]">실제 연동 전에도 데모로 전체 흐름을 볼 수 있어요.</p>
                    <div className="mt-4 space-y-3">
                      <div className="rounded-2xl bg-[var(--bg)] p-4"><p className="text-[13px] font-black">Step 1 · Kakao Developers에서 앱 만들기</p><p className="mt-1 text-[12px] leading-relaxed text-[var(--muted)]">Kakao Developers에서 앱을 만들고, 카카오 로그인을 활성화해 주세요.</p></div>
                      <div className="rounded-2xl bg-[var(--bg)] p-4"><label className="text-[13px] font-black" htmlFor="kakao-key-modal">Step 2 · REST API 키 입력</label><input id="kakao-key-modal" value={kakaoKey} onChange={e => setKakaoKey(e.target.value)} placeholder="REST API 키를 입력해 주세요" autoComplete="off" className="mt-2 w-full rounded-xl border border-[var(--line)] bg-[var(--surface)] px-3 py-3 text-[13px] font-bold outline-none focus:border-[var(--accent)]" /><p className="mt-1.5 text-[11px] leading-relaxed text-[var(--muted)]">키는 코드에 저장하지 않아요. 저장하면 기록 API에 저장돼요.</p></div>
                      <div className="rounded-2xl bg-[var(--bg)] p-4"><label className="text-[13px] font-black" htmlFor="kakao-redirect-modal">Step 3 · Redirect URI 입력</label><input id="kakao-redirect-modal" value={kakaoRedirect} onChange={e => setKakaoRedirect(e.target.value)} placeholder="Redirect URI" autoComplete="off" className="mt-2 w-full rounded-xl border border-[var(--line)] bg-[var(--surface)] px-3 py-3 text-[13px] font-bold outline-none focus:border-[var(--accent)]" /><p className="mt-1.5 text-[11px] leading-relaxed text-[var(--muted)]">기본값: 현재 origin + /auth/kakao/callback</p></div>
                    </div>
                    {kakaoOAuthUrl && <div className="mt-4 rounded-2xl border border-[var(--line)] bg-[var(--surface)] p-4"><p className="text-[13px] font-black">실제 OAuth 주소 미리보기</p><p className="mt-2 break-all rounded-xl bg-[var(--bg)] p-3 font-mono text-[11px] leading-relaxed">{kakaoOAuthUrl}</p><a href={kakaoOAuthUrl} target="_blank" rel="noopener" className="mt-3 block rounded-xl bg-[#FEE500] py-3 text-center text-[14px] font-black text-[#1A1A1A]">카카오 로그인 페이지 열기</a><p className="mt-2 text-[11px] leading-relaxed text-[var(--muted)]">실제 연동은 Vercel 배포 후 Redirect URI를 Kakao Developers에 등록해야 해요.</p></div>}
                    <button onClick={saveKakaoSettings} disabled={kakaoSaving} className="mt-4 w-full rounded-2xl border-2 border-[var(--line)] bg-[var(--surface)] py-3.5 text-[14px] font-black disabled:opacity-50">{kakaoSaving ? '저장 중…' : '카카오 설정 저장하기'}</button>
                    <p className="mt-2 text-center text-[11px] font-bold text-[var(--muted)]">{kakaoSettingsMessage}</p>
                    <button onClick={startKakaoDemo} className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl bg-[#FEE500] py-4 text-[15px] font-black text-[#1A1A1A]">카카오 로그인 테스트 (데모)</button>
                    <p className="mt-2 text-center text-[11px] leading-relaxed text-[var(--muted)]">데모를 누르면 닉네임 · 프로필 이미지 자리 · 마스킹된 이메일이 돌아온 뒤, 전화번호 인증으로 이동해요.</p>
                    <button onClick={startPhoneFlow} className="mt-2 w-full rounded-2xl bg-[var(--bg)] py-3 text-[13px] font-bold text-[var(--muted)]">전화번호로 시작하기</button>
                  </div>
                </div>
              )}
              {kakaoProfile && <div className="mt-4 rounded-[22px] border border-[var(--line)] bg-[var(--surface)] p-4"><p className="text-[13px] font-black">카카오 데모 프로필 미리보기</p><div className="mt-3 flex items-center gap-3"><span className="flex h-11 w-11 items-center justify-center rounded-full bg-[#FEE500] text-[18px] font-black text-[#1A1A1A]">{kakaoProfile.image}</span><div><p className="text-[14px] font-black">{kakaoProfile.nickname}</p><p className="text-[12px] text-[var(--muted)]">{kakaoProfile.email}</p></div></div><button onClick={() => { setLoginMethod('kakao'); setStage('onboarding'); setOnStep(1); }} className="mt-3 w-full rounded-xl bg-[var(--accent)] py-3 text-[14px] font-black text-white">전화번호 인증으로 이어하기</button></div>}
            </div>
          )}
          {stage === 'onboarding' && (
            <div className="px-5 pb-8 pt-4">
              <button onClick={() => setStage('login')} className="mb-3 flex items-center gap-1 text-[12px] font-bold text-[var(--muted)]"><ArrowLeft size={14}/>로그인으로 돌아가기</button>
              <div className="flex items-center justify-between"><div className="flex gap-1.5">{[0,1,2,3,4].map(i => <span key={i} className={`h-1.5 w-6 rounded-full ${i <= onStep ? 'bg-[var(--accent)]' : 'bg-[var(--line)]'}`} />)}</div><span className="text-[11px] font-bold text-[var(--muted)]">{onStep === 0 ? '1 / 5 · 국적 선택' : `${onStep + 1} / 5 · 시작하기`}</span></div>
              <div className="mt-10 text-center"><div className="mx-auto flex h-16 w-16 items-center justify-center rounded-[22px] bg-[var(--accent)] text-3xl shadow-lg shadow-orange-200">☕</div><h1 className="serif mt-5 text-[42px] font-black leading-none tracking-tight">애프터</h1><p className="mt-3 text-[15px] font-bold text-[var(--muted)]">채팅 없이, 만나서 알아가는 소개팅</p><p className="mx-auto mt-2 max-w-[290px] text-[12px] leading-relaxed text-[var(--muted)]">첫 만남은 데이트 신청, 2번째부터 애프터,<br />3번 만나면 연애 시작할지 결정해요.</p><p className="mx-auto mt-2 max-w-[290px] text-[11px] leading-relaxed text-[var(--muted)]">하루 6명 · 초기에는 사람이 적어서 6명으로 시작해요.</p></div>

              {onStep === 0 ? (
                <div className="mt-8">
                  <p className="text-[12px] font-black tracking-wider text-[var(--muted)]">{loginMethod === 'kakao' ? 'STEP 3 · 국적 선택' : 'STEP 1 · 국적 선택'}</p><h2 className="mt-2 text-[20px] font-black">어떤 인증으로 시작할까요?</h2><p className="mt-1 text-[13px] leading-relaxed text-[var(--muted)]">국적을 선택해 주세요. 국적과 상관없이 같은 한국 전화번호 본인인증으로 시작해요.</p>
<div className="mt-4 space-y-3">
                    <button onClick={() => { setNationality('korean'); setUiLang('ko'); showToast('대한민국 국적 인증으로 시작해요'); }} className={`w-full rounded-[22px] p-4 text-left shadow-sm ${nationality==='korean' ? 'select-card-selected' : 'select-card'}`}><span className="text-2xl">🇰🇷</span><p className="mt-2 text-[15px] font-black text-[#1A1A1A]">대한민국 국적</p><p className="mt-1 text-[12px] leading-relaxed text-[#5A534D]">한국 휴대폰 본인인증으로 시작해요. 본인인증 결과로 확정돼요.</p><p className="mt-2 flex items-center gap-1 text-[11px] font-black text-[#C94A30]"><Lock size={12}/>성별은 한 번 정하면 수정할 수 없어요{nationality==='korean' && <span className="ml-1 flex items-center gap-1"><Check size={13}/>선택됨</span>}</p></button>
                    <button onClick={() => { setNationality('foreigner'); pickForeignCountry(foreignCountry); showToast('외국인 인증으로 시작해요'); }} className={`w-full rounded-[22px] p-4 text-left shadow-sm ${nationality==='foreigner' ? 'select-card-selected' : 'select-card'}`}><span className="text-2xl">🌍</span><p className="mt-2 text-[15px] font-black text-[#1A1A1A]">외국인</p><p className="mt-1 text-[12px] leading-relaxed text-[#5A534D]">한국 휴대폰 본인인증으로 시작해요. 본인인증 결과로 성별이 확정돼요.</p><p className="mt-2 flex items-center gap-1 text-[11px] font-black text-[#C94A30]"><Lock size={12}/>성별은 한 번 정하면 수정할 수 없어요{nationality==='foreigner' && <span className="ml-1 flex items-center gap-1"><Check size={13}/>선택됨</span>}</p></button>
                  </div>
                  {nationality === 'foreigner' && (
                    <div className="mt-4">
                      <p className="text-[13px] font-black">어느 나라에서 오셨어요?</p>
                      <div className="mt-2 grid grid-cols-4 gap-2">{FOREIGN_COUNTRIES.map(c => <button key={c.id} onClick={() => pickForeignCountry(c.id)} className={`rounded-[16px] p-2.5 text-center ${foreignCountry===c.id ? 'select-card-selected' : 'select-card'}`}><span className="text-xl">{c.flag}</span><span className="mt-1 block text-[12px] font-black text-[#1A1A1A]">{c.label}</span>{foreignCountry===c.id && <span className="mt-0.5 block text-[10px] font-black text-[#C94A30]">선택됨</span>}</button>)}</div>
                      <div className="mt-3 rounded-[18px] bg-[var(--sage-bg)] p-4"><p className="flex items-center gap-2 text-[13px] font-black"><Globe size={16} className="text-[#6E9A7E]" />선택한 국적에 맞게 언어가 자동 번역돼요</p><p className="mt-1 text-[12px] leading-relaxed text-[var(--muted)]">{foreignCountry} 선택 · 자동 번역 언어는 {LANG_LABEL[uiLang]}예요. 아래에서 바꿀 수 있어요.</p><div className="mt-3 flex flex-wrap gap-2">{LANGUAGE_OPTIONS.map(l => <button key={l.id} onClick={() => setUiLang(l.id)} className={`rounded-full px-3.5 py-2 text-[12px] font-black ${uiLang===l.id ? 'bg-[var(--accent)] text-white' : 'bg-[var(--surface)] text-[var(--ink)]'}`}>{l.label}</button>)}</div><p className="mt-2 text-[11px] leading-relaxed text-[var(--muted)]">미리보기 · {bi('데이트 신청하기', 'dateRequest')}</p></div>
                    </div>
                  )}
                  <p className="mt-3 rounded-[18px] bg-[var(--sage-bg)] p-3 text-[11px] leading-relaxed text-[var(--muted)]">국적과 상관없이 한국 전화번호 본인인증이 필요해요. 장기 체류자 중심의 앱이에요. 회사 인증은 내국인과 동일하게 진행해요. 인증 정보는 상대에게 공개되지 않아요.</p>
                  <button onClick={() => { if (!nationality) return showToast('국적을 먼저 선택해 주세요'); if (phoneDone) { setOnStep(2); showToast('카카오 로그인 후 전화번호 인증이 끝났어요'); } else { setOnStep(1); showToast('한국 휴대폰 본인인증으로 시작해요'); } }} className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-[var(--accent)] py-4 text-[16px] font-black text-white">{phoneDone ? '다음으로' : '한국 전화번호 인증으로 계속하기'} <ArrowRight size={18}/></button>
                </div>
              ) : onStep === 1 ? (
                  <div className="mt-8 rounded-[24px] border border-[var(--line)] bg-[var(--surface)] p-5 shadow-sm">
                    <p className="text-[12px] font-black tracking-wider text-[var(--muted)]">STEP 2 · 본인 확인용 전화번호 인증 (PASS는 정식 출시 때 추가) {nationality === 'foreigner' ? `· ${foreignCountry}` : ''}</p><h2 className="mt-2 text-[20px] font-black">본인 확인부터 시작해요</h2>{kakaoProfile && <div className="mt-3 flex items-center gap-3 rounded-[18px] bg-[#FFF6EF] p-3"><span className="flex h-10 w-10 items-center justify-center rounded-full bg-[#FEE500] text-[16px] font-black text-[#1A1A1A]">{kakaoProfile.image}</span><div><p className="text-[13px] font-black">{kakaoProfile.nickname} 님 · 카카오로 로그인했어요</p><p className="text-[11px] text-[var(--muted)]">{kakaoProfile.email} · 데모 프로필 미리보기예요</p></div><span className="ml-auto rounded-full bg-[var(--sage-bg)] px-2 py-1 text-[10px] font-black text-[#4F7A5D]">카카오 연결됨</span></div>}<p className="mt-1 text-[13px] leading-relaxed text-[var(--muted)]">국적과 상관없이 한국 전화번호 본인인증이 필요해요. 장기 체류자 중심의 앱이에요.</p>
                    {nationality === 'foreigner' && <div className="mt-3 flex items-center gap-2 rounded-[16px] bg-[var(--sage-bg)] p-3 text-[12px] font-bold"><Globe size={15} className="shrink-0 text-[#6E9A7E]" />선택한 국적에 맞게 언어가 자동 번역돼요 · {LANG_LABEL[uiLang]}</div>}
                    <label className="mt-5 block text-[12px] font-bold text-[var(--muted)]">한국 휴대폰 번호</label>
                    <div className="mt-1.5 flex gap-2"><input value={phone} onChange={e => setPhone(e.target.value.replace(/[^0-9-]/g, ''))} placeholder="010-0000-0000" className="min-w-0 flex-1 rounded-xl border border-[var(--line)] bg-[var(--bg)] px-3 py-3 text-[15px] font-bold outline-none focus:border-[var(--accent)]" /><button onClick={() => { if (phone.length >= 10) { setCodeSent(true); showToast('인증번호를 보냈어요'); } else showToast('휴대폰 번호를 입력해 주세요'); }} className="shrink-0 rounded-xl bg-[var(--ink)] px-3.5 py-3 text-[13px] font-bold text-white">인증번호 받기</button></div>
                    {codeSent && (<><label className="mt-4 block text-[12px] font-bold text-[var(--muted)]">인증번호 6자리</label><input value={code} onChange={e => setCode(e.target.value.replace(/[^0-9]/g, '').slice(0,6))} placeholder="000000" inputMode="numeric" className="mt-1.5 w-full rounded-xl border border-[var(--line)] bg-[var(--bg)] px-3 py-3 text-[15px] font-bold tracking-[0.3em] outline-none focus:border-[var(--accent)]" /><button onClick={() => { if (code.length === 6) { setPhoneDone(true); setGenderLocked(true); if (!nationality) { setOnStep(0); showToast('전화번호 인증이 끝났어요 · 국적을 선택해 주세요'); } else { setOnStep(2); } } else showToast('인증번호 6자리를 입력해 주세요'); }} className="mt-3 w-full rounded-xl bg-[var(--accent)] py-3.5 text-[15px] font-black text-white">인증 확인하기</button><p className="mt-2 text-center text-[11px] text-[var(--muted)]">예시 화면이에요 · 데모 인증번호는 123456이에요</p></>)}
                    <div className="mt-4 flex gap-2 rounded-xl bg-[var(--sage-bg)] p-3 text-[11px] leading-relaxed text-[var(--ink)]"><ShieldCheck size={16} className="shrink-0 text-[#6E9A7E]" />전화번호는 상대에게 공개되지 않아요. 만남은 1회성 위치 인증으로 확인해요.</div>
                    <div className="mt-3 rounded-[18px] border-2 border-white/20 bg-[#1A1A1A] p-4 text-[#FFFFFF]"><p className="flex items-center gap-2 text-[14px] font-black text-[#FFFFFF]"><Lock size={15} className="shrink-0 text-[#FFFFFF]" />나이 인증은 어떻게 해요?</p><p className="mt-2 text-[13px] font-bold leading-relaxed text-[#FFFFFF]">나이는 따로 인증하지 않아요. 휴대폰 본인인증에서 생년월일이 확인되면 나이가 자동 계산돼요.</p><p className="mt-2 rounded-xl bg-white/10 px-3 py-2 text-[12px] font-bold text-[#FFFFFF]">예시 · 나이: 28세 (본인인증으로 확인됨)</p><p className="mt-2 text-[11px] leading-relaxed text-white/80">별도로 여권이나 신분증을 제출할 필요가 없어요. 생년월일은 상대에게 공개되지 않아요.</p></div>
                    <div className="mt-3 flex gap-2 rounded-xl bg-[var(--sage-bg)] p-3 text-[11px] leading-relaxed text-[var(--ink)]"><Lock size={16} className="shrink-0 text-[#6E9A7E]" /><span><b>본인인증 결과로 확정되며, 한 번 정하면 수정할 수 없어요</b><br/>성별은 본인인증 결과로 확정돼요.</span></div>
                    <button onClick={() => { if (nationality) setOnStep(0); else setStage('login'); }} className="mt-3 w-full py-2 text-[12px] font-bold text-[var(--muted)]">{nationality ? '국적 다시 선택하기' : '로그인으로 돌아가기'}</button>
                  </div>
              ) : onStep === 2 ? (
                  <div className="mt-8">
                    <p className="text-[12px] font-black tracking-wider text-[var(--muted)]">STEP 2 · 성별 확인</p><h2 className="mt-2 text-[20px] font-black">성별이 자동 확정됐어요</h2><p className="mt-1 text-[13px] leading-relaxed text-[var(--muted)]">이 정보는 매칭에만 사용돼요.</p>
                    <div className="mt-5 rounded-[22px] border border-[var(--line)] bg-[var(--surface)] p-4"><div className="flex items-center justify-between"><p className="text-[14px] font-black">A · 내 성별</p><span className="flex items-center gap-1 rounded-full bg-[var(--bg)] px-2.5 py-1 text-[11px] font-black text-[var(--muted)]"><Lock size={12}/>수정 불가</span></div><p className="mt-3 text-[22px] font-black">{profileGenderLabel}</p><p className="mt-2 flex items-center gap-1 text-[12px] font-bold text-[var(--ink)]"><Lock size={13}/>{genderLockMessage}</p><p className="mt-1 text-[12px] leading-relaxed text-[var(--muted)]">{genderLockNote}</p></div>
                    <div className="mt-3 rounded-[18px] border-2 border-white/20 bg-[#1A1A1A] p-4 text-[#FFFFFF]"><p className="flex items-center gap-2 text-[13px] font-black text-[#FFFFFF]"><Lock size={14} />나이: 28세 (본인인증으로 확인됨)</p><p className="mt-1.5 text-[12px] leading-relaxed text-white/85">나이는 따로 인증하지 않아요. 휴대폰 본인인증에서 생년월일이 확인되면 나이가 자동 계산돼요.</p></div>
                    <p className="mt-5 text-[14px] font-black">B · 만나고 싶은 상대의 성별</p>
                    <div className="mt-2 grid grid-cols-3 gap-2">{(['남성','여성','모두'] as DesiredGender[]).map(g => <button key={g} onClick={()=>setDesiredGender(g)} className={`rounded-[20px] p-3 text-center ${desiredGender===g ? 'select-card-selected' : 'select-card'}`}><span className="text-2xl">{g==='남성' ? '👨' : g==='여성' ? '👩' : '👥'}</span><p className="mt-2 text-[14px] font-black text-[#1A1A1A]">{g}</p>{desiredGender===g && <p className="mt-1 flex items-center justify-center gap-1 text-[11px] font-black text-[#C94A30]"><Check size={13}/>선택됨</p>}</button>)}</div>
                    <div className="mt-4 rounded-[18px] bg-[var(--sage-bg)] p-4"><p className="text-[11px] font-bold text-[var(--muted)]">미리보기</p><p className="mt-1 text-[14px] font-black">{profilePreview}</p><p className="mt-1 text-[11px] leading-relaxed text-[var(--muted)]">만나고 싶은 상대: {desiredGender} · 이 조건으로 오늘 추천을 골라요.</p></div>
                    <button onClick={() => setOnStep(3)} className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-[var(--accent)] py-4 text-[16px] font-black text-white">다음으로 <ArrowRight size={18}/></button>
                    <button onClick={() => setOnStep(1)} className="mt-2 w-full py-2 text-[12px] font-bold text-[var(--muted)]">휴대폰 인증으로 돌아가기</button>
                  </div>
              ) : onStep === 3 ? (
                <div className="mt-8">
                  <p className="text-[12px] font-black tracking-wider text-[var(--muted)]">STEP 3 · 소속 인증</p><h2 className="mt-2 text-[20px] font-black">어떤 소속으로 인증할까요?</h2><p className="mt-1 text-[13px] text-[var(--muted)]">하나를 선택해 주세요. 인증 정보는 상대에게 공개되지 않아요.</p>{nationality === 'foreigner' && <p className="mt-3 flex items-center gap-2 rounded-[18px] bg-[var(--sage-bg)] p-3 text-[12px] font-bold"><ShieldCheck size={15} className="shrink-0 text-[#6E9A7E]"/>회사 인증은 내국인과 동일하게 진행해요.</p>}
                  <div className="mt-4 grid grid-cols-2 gap-3">{verifyCards.map(c => <button key={c.id} onClick={() => setVerify(c.id)} className={`rounded-[20px] p-4 text-left ${verify === c.id ? 'select-card-selected' : 'select-card'}`}><span className="text-2xl">{c.icon}</span><p className="mt-3 text-[14px] font-black text-[#1A1A1A]">{c.title}</p><p className="mt-1 text-[11px] leading-relaxed text-[#5A534D]">{c.desc}</p>{verify === c.id && <p className="mt-2 flex items-center gap-1 text-[11px] font-black text-[#C94A30]"><Check size={13}/>선택됨</p>}</button>)}</div>
                  {verify === 'business' && (<div className="mt-3 rounded-[20px] border border-dashed border-[var(--accent)] bg-[var(--surface)] p-4"><button onClick={() => { setUploaded(true); showToast('사업자등록증 사진이 첨부됐어요'); }} className="flex w-full flex-col items-center gap-2 py-2"><Upload className="text-[var(--accent)]" /><span className="text-[13px] font-black">{uploaded ? '사업자등록증 사진 첨부 완료' : '사업자등록증 사진 업로드'}</span><span className="text-[11px] text-[var(--muted)]">{uploaded ? '검증용으로만 사용돼요' : '사진을 눌러 첨부해 보세요'}</span></button><p className="mt-2 border-t border-[var(--line)] pt-3 text-[11px] leading-relaxed text-[var(--muted)]">서류는 검증용으로만 사용되며 상대에게 공개되지 않습니다.</p></div>)}
                  {verify === 'later' && (<div className="mt-3 rounded-[20px] bg-[#FFF6E6] p-4 text-[12px] leading-relaxed"><p className="flex items-center gap-2 font-black"><span className="rounded-full bg-white px-2.5 py-1 text-[11px] text-[var(--muted)]">미인증</span>인증 없이 시작할 수 있어요.</p><p className="mt-2 text-[var(--muted)]">단, 인증 안 한 사람은 인증 안 한 사람끼리만 추천돼요.</p></div>)}
                  <div className="mt-3 flex items-center gap-2 rounded-[18px] bg-[var(--sage-bg)] px-4 py-3 text-[12px] font-bold"><span className="flex h-6 w-6 items-center justify-center rounded-full bg-[#6E9A7E] text-white">✓</span>{verify === 'later' ? '미인증으로 시작하기' : `인증 완료 - ${verifyLabel}`} <span className="ml-auto rounded-full bg-white px-2 py-1 text-[10px] text-[var(--muted)]">{verify === 'later' ? '미인증' : '미리보기'}</span></div>
                  <button onClick={() => setOnStep(4)} className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-[var(--accent)] py-4 text-[16px] font-black text-white">다음으로 <ArrowRight size={18}/></button>
                  <button onClick={() => setOnStep(2)} className="mt-2 w-full py-2 text-[12px] font-bold text-[var(--muted)]">성별 선택으로 돌아가기</button>
                </div>
              ) : (
                <div className="mt-8">
                  <p className="text-[12px] font-black tracking-wider text-[var(--muted)]">STEP 4 · 얼굴 인증</p><h2 className="mt-2 text-[20px] font-black">얼굴 인증을 해볼까요?</h2><p className="mt-1 text-[13px] leading-relaxed text-[var(--muted)]">프로필 사진이 본인인지 확인해요. 얼굴 인증용 셀카는 검증용으로만 보관하고, 프로필 사진으로 강제하지 않아요.</p>
                  <div className="mt-4 rounded-[22px] border border-dashed border-[var(--accent)] bg-[var(--surface)] p-4"><button onClick={() => { setFaceUploaded(true); showToast('셀카가 첨부됐어요'); }} className="flex w-full flex-col items-center gap-2 py-3"><span className="flex h-12 w-12 items-center justify-center rounded-full bg-[#FFF1EB]"><Camera className="text-[var(--accent)]" /></span><span className="text-[14px] font-black">{faceUploaded ? '셀카 첨부 완료' : '셀카 촬영 / 업로드'}</span><span className="text-[11px] text-[var(--muted)]">{faceUploaded ? '검증용으로만 사용돼요' : '얼굴이 잘 보이게 찍어 주세요'}</span></button><p className="mt-2 border-t border-[var(--line)] pt-3 text-[11px] leading-relaxed text-[var(--muted)]">얼굴 인증용 셀카는 검증용으로만 보관돼요. 상대에게는 공개되지 않아요.</p></div>
                  <button onClick={() => { if (!faceUploaded) return showToast('셀카를 먼저 첨부해 주세요'); setFaceVerified(true); showToast('얼굴 인증이 완료됐어요'); }} className="mt-3 w-full rounded-2xl bg-[var(--ink)] py-4 text-[15px] font-black text-white">얼굴 인증하기</button>
                  {faceVerified && <div className="mt-3 flex items-center gap-2 rounded-[18px] bg-[var(--sage-bg)] px-4 py-3 text-[12px] font-bold"><span className="flex h-6 w-6 items-center justify-center rounded-full bg-[#6E9A7E] text-white"><Check size={14} /></span>얼굴 인증 완료 <span className="ml-auto rounded-full bg-white px-2 py-1 text-[10px] text-[var(--muted)]">프로필에 표시돼요</span></div>}
                  <button onClick={() => setStage('ideal')} className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-[var(--accent)] py-4 text-[16px] font-black text-white">다음으로 <ArrowRight size={18}/></button>
                  <button onClick={() => setOnStep(3)} className="mt-2 w-full py-2 text-[12px] font-bold text-[var(--muted)]">소속 인증으로 돌아가기</button>
                </div>
              )}
            </div>
          )}

          {stage === 'ideal' && (
            <div className="px-5 pb-8 pt-4">
              <button onClick={() => setStage('onboarding')} className="flex items-center gap-1 text-[13px] font-bold text-[var(--muted)]"><ArrowLeft size={16}/>뒤로</button>
              <div className="mt-4"><SectionTitle kicker="IDEAL TYPE" title="어떤 사람을 만나고 싶어요?" sub="만나고 싶은 상대 등 선택은 언제든 바꿀 수 있어요. 내 성별은 온보딩에서 확정돼요. 오늘 추천에 바로 반영돼요. 하루 6명 · 초기에는 사람이 적어서 6명으로 시작해요." /></div>
              <div className="mt-6 space-y-6">
                <div className="rounded-[22px] border border-[var(--line)] bg-[var(--surface)] p-4"><p className="text-[14px] font-black">성별 · 만나고 싶은 상대</p><p className="mt-1 text-[12px] leading-relaxed text-[var(--muted)]">내 성별은 온보딩에서 확정됐어요. 만나고 싶은 상대는 여기서 바꿀 수 있어요.</p><div className="mt-3 rounded-xl bg-[var(--bg)] p-3"><p className="flex items-center gap-1 text-[12px] font-black"><Lock size={12}/>내 성별 · {profileGenderLabel} · 수정 불가</p><p className="mt-1 flex items-center gap-1 text-[11px] font-bold text-[var(--ink)]"><Lock size={12}/>{genderLockMessage}</p><p className="mt-1 text-[11px] leading-relaxed text-[var(--muted)]">{genderLockNote}</p></div><p className="mt-3 text-[12px] font-black">만나고 싶은 상대의 성별</p><div className="mt-2 flex flex-wrap gap-2">{(['남성','여성','모두'] as DesiredGender[]).map(v => <Chip key={v} active={desiredGender===v} onClick={()=>setDesiredGender(v)}>{v}</Chip>)}</div><p className="mt-3 rounded-xl bg-[var(--sage-bg)] p-3 text-[12px] font-bold">{profilePreview}</p></div>
                <div><p className="mb-2 text-[14px] font-black">나이 범위</p><div className="flex flex-wrap gap-2">{['24–28세','26–30세','28–33세','30–35세'].map(v => <Chip key={v} active={ageRange===v} onClick={()=>setAgeRange(v)}>{v}</Chip>)}</div></div>
                <div><p className="mb-2 text-[14px] font-black">자주 만날 수 있는 지역</p><div className="flex flex-wrap gap-2">{['강남','성수','홍대','이태원','잠실','연남'].map(v => <Chip key={v} active={areas.includes(v)} onClick={()=>toggle(areas,v,setAreas)}>{v}</Chip>)}</div></div>
                <div><div className="mb-2 flex items-center justify-between"><p className="text-[14px] font-black">만나고 싶은 유형</p><span className="rounded-full bg-[var(--surface2)] px-2.5 py-1 text-[11px] font-black text-[var(--accent)]">최대 3개 · {types.length}/3</span></div><div className="flex flex-wrap gap-2">{['대화가 잘 통하는 사람','활동적인 사람','차분한 사람','유머 있는 사람'].map(v => <Chip key={v} active={types.includes(v)} onClick={()=>toggle(types,v,setTypes,3)}>{v}</Chip>)}</div></div>
                <div><p className="mb-2 text-[14px] font-black">데이트 스타일</p><div className="flex flex-wrap gap-2">{['카페','산책','전시','식사','운동'].map(v => <Chip key={v} active={styles.includes(v)} onClick={()=>toggle(styles,v,setStyles)}>{v}</Chip>)}</div></div>
                <div><p className="mb-2 text-[14px] font-black">만날 수 있는 시간대</p><div className="flex flex-wrap gap-2">{['평일 저녁','주말 오후','주말 저녁'].map(v => <Chip key={v} active={times.includes(v)} onClick={()=>toggle(times,v,setTimes)}>{v}</Chip>)}</div></div>
                <div className="rounded-[22px] border border-[var(--line)] bg-[var(--surface)] p-4"><div className="flex items-center justify-between gap-2"><div className="flex items-center gap-2"><Languages size={17} className="text-[var(--accent)]"/><h3 className="text-[15px] font-black">자기소개</h3></div><span className="flex items-center gap-1 rounded-full bg-[var(--sage-bg)] px-2.5 py-1 text-[10px] font-black text-[#4F7A5D]"><Languages size={11}/>자동 번역됨</span></div><p className="mt-1 text-[12px] leading-relaxed text-[var(--muted)]">자기소개는 편한 언어로 쓰세요. 상대의 언어에 맞게 자동 번역돼서 보여요.</p><label className="mt-3 block text-[12px] font-bold text-[var(--muted)]">자기소개 원문 · 한국어</label><textarea value={myIntro} onChange={e => setMyIntro(e.target.value)} rows={3} placeholder="편한 언어로 자기소개를 적어 보세요." className="mt-1.5 w-full resize-none rounded-xl border border-[var(--line)] bg-[var(--bg)] px-3 py-2.5 text-[13px] leading-relaxed outline-none focus:border-[var(--accent)]" /><div className="mt-3 flex rounded-full bg-[var(--bg)] p-1"><button onClick={()=>{setMyIntroMode('original'); showToast('원문 미리보기로 바꿨어요');}} className={`flex-1 rounded-full py-2 text-[12px] font-black ${myIntroMode==='original' ? 'bg-[var(--ink)] text-white' : 'text-[var(--muted)]'}`}>원문 보기</button><button onClick={()=>{setMyIntroMode('translated'); showToast('번역본 미리보기로 바꿨어요');}} className={`flex-1 rounded-full py-2 text-[12px] font-black ${myIntroMode==='translated' ? 'bg-[var(--accent)] text-white' : 'text-[var(--muted)]'}`}>번역본 보기</button></div><div className="mt-3 rounded-xl bg-[var(--bg)] p-3"><p className="text-[11px] font-black text-[var(--muted)]">{myIntroMode==='original' ? '미리보기 · 원문' : '미리보기 · 번역본 · English'}</p><p className="mt-1 text-[13px] leading-relaxed">{myIntroMode==='original' ? (myIntro || '자기소개를 입력해 보세요.') : myIntroTranslated}</p>{myIntroMode==='translated' && <p className="mt-2 flex items-center gap-1 text-[11px] font-bold text-[#4F7A5D]"><Languages size={12}/>자동 번역됨 · 자동 번역으로 뉘앙스가 다를 수 있어요</p>}</div><p className="mt-2 text-[11px] leading-relaxed text-[var(--muted)]">예시 · 한국어로 쓰면 아래처럼 보여요. 원문도 함께 보관돼요.</p><div className="mt-2 space-y-2"><p className="rounded-xl bg-[var(--bg)] p-3 text-[13px] leading-relaxed"><span className="block text-[10px] font-black text-[var(--muted)]">원문 · 한국어</span>{MY_INTRO_DEFAULT}</p><p className="rounded-xl bg-[#FFF1EB] p-3 text-[13px] leading-relaxed"><span className="block text-[10px] font-black text-[var(--accent)]">번역본 · English</span>{MY_INTRO_EN}</p></div></div>
                <div className="rounded-[22px] border border-[var(--line)] bg-[var(--surface)] p-4"><div className="flex items-center gap-2"><MessageCircle size={17} className="text-[var(--accent)]"/><h3 className="text-[15px] font-black">첫 만남에서 이런 얘기 하고 싶어요</h3></div><p className="mt-1 text-[12px] text-[var(--muted)]">답을 미리 적어두면 첫 만남이 훨씬 편해져요. 첫 만남 질문도 상대 언어에 맞게 자동 번역돼요.</p>
                  {[['요즘 뭐가 제일 즐거우세요?','요즘 가장 즐겁게 하는 일'],['어떤 사람과 오래 만나고 싶어요?','만나고 싶은 사람의 모습'],['편한 만남은 어떤 모습인가요?','편하다고 느끼는 만남']].map((q,i) => <div key={q[0]} className="mt-4"><p className="text-[13px] font-bold">Q{i+1}. {q[0]}</p><textarea value={answers[i]} onChange={e => { const n=[...answers]; n[i]=e.target.value; setAnswers(n); }} rows={2} className="mt-1.5 w-full resize-none rounded-xl border border-[var(--line)] bg-[var(--bg)] px-3 py-2.5 text-[13px] leading-relaxed outline-none focus:border-[var(--accent)]" /></div>)}
                </div>
              </div>
              <button onClick={() => { setStage('main'); setTab('recommend'); setMatchPreview('mine'); showToast('오늘의 추천이 준비됐어요'); }} className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl bg-[var(--accent)] py-4 text-[16px] font-black text-white">오늘의 추천 보기 <ArrowRight size={18}/></button>
            </div>
          )}

          {stage === 'main' && view === 'main' && (
            <div className="pb-6">
              {tab === 'home' && (
                <div className="px-5 pt-3">
                  {isForeign && <div className="mb-3 rounded-[18px] bg-[var(--sage-bg)] p-3"><p className="flex items-center gap-2 text-[12px] font-black"><Globe size={14} className="text-[#6E9A7E]" />선택한 국적에 맞게 언어가 자동 번역돼요 · {foreignCountry} · {LANG_LABEL[uiLang]}</p><p className="mt-1 text-[11px] leading-relaxed text-[var(--muted)]">주요 버튼은 한국어와 함께 번역 미리보기로 보여요.</p><div className="mt-2 flex gap-2"><button onClick={()=>{ setUiLang('ko'); showToast('표시 언어를 한국어로 바꿨어요'); }} className={`rounded-full px-3 py-1.5 text-[11px] font-black ${uiLang==='ko' ? 'bg-[var(--accent)] text-white' : 'bg-[var(--surface)] text-[var(--ink)]'}`}>한국어</button><button onClick={()=>{ setUiLang('en'); showToast('표시 언어를 English로 바꿨어요'); }} className={`rounded-full px-3 py-1.5 text-[11px] font-black ${uiLang==='en' ? 'bg-[var(--accent)] text-white' : 'bg-[var(--surface)] text-[var(--ink)]'}`}>English</button><span className="self-center text-[10px] font-bold text-[var(--muted)]">데모용 한국어 ↔ English 전환</span></div></div>}
                  <div className="flex items-start justify-between"><div><p className="text-[12px] font-bold text-[var(--muted)]">11월 18일 수요일 · 좋은 만남이 기다려요</p><h2 className="serif mt-1 text-[28px] font-black leading-tight">오늘도, 만나서<br/>알아가는 하루</h2>{isForeign && langTrans && <p className="mt-1 text-[12px] font-bold text-[var(--muted)]">{langTrans.header}</p>}</div><button onClick={()=>showToast('새 알림이 없어요')} className="relative rounded-full bg-[var(--surface)] p-3 shadow-sm"><Bell size={18}/><span className="absolute right-2.5 top-2.5 h-2 w-2 rounded-full bg-[var(--accent)]"/></button></div>
                  <div className="mt-5 overflow-hidden rounded-[24px] bg-[#2B2622] p-5 text-white"><p className="text-[11px] font-black tracking-widest text-[#FFB59F]">NEXT · 3차 애프터 · 11/19 수 19:00</p><p className="mt-2 text-[20px] font-black">지우 님과 성수 카페</p><p className="mt-1 text-[12px] text-white/70">세 번째 만남 · 대화가 잘 통하는 사람</p><div className="mt-3 space-y-1.5 text-[12px]"><p className="flex items-center gap-2"><span className="inline-block h-3 w-3 rounded-full border border-white/50" style={{background:(DRESS_COLORS.find(c=>c.id===dressColor)||DRESS_COLORS[0]).swatch}}/>드레스코드 · {dressConfirmed ? `${dressColorDesc} + ${dressItemLabel}` : `${dressColorDesc} + ${dressItemLabel} · 아직 확정 전`}</p><p className="flex items-center gap-2"><Vibrate size={14} className="text-[#FFB59F]"/>{proximityOn ? (proximityDistance === null ? '진동 알림 켜짐 · 상대가 가까워지면 알려줘요' : proximityDistance === 0 ? '진동 알림 · 지우 님이 도착했어요' : `진동 알림 켜짐 · 상대 약 ${proximityDistance}m`) : '진동 알림 꺼짐'}</p></div><div className="mt-4 flex gap-2"><button onClick={()=>setView('feedback')} className="flex-1 rounded-xl bg-white py-3 text-[13px] font-black text-[#2B2622]">어제 어땠어요?</button><button onClick={()=>{setTab('calendar');}} className="flex-1 rounded-xl border border-white/30 py-3 text-[13px] font-bold">일정 확인</button></div>{verifiedIds.includes(101) ? <p className="mt-2 w-full rounded-xl bg-white/10 py-2.5 text-center text-[12px] font-bold text-white">만남 인증 완료 · 1회성 위치 인증</p> : <button onClick={()=>startArrival(101)} className="mt-2 w-full rounded-xl bg-white/10 py-2.5 text-[12px] font-bold text-white">도착했어요 · 1회성 위치 인증</button>}<button onClick={()=>setView('checkin')} className="mt-2 w-full rounded-xl bg-white/10 py-2.5 text-[12px] font-bold text-white">1회성 위치 인증 · 드레스코드 · 진동 알림 보기</button></div>
                  <div className="mt-4 rounded-[22px] border border-[var(--line)] bg-[var(--surface)] p-4"><div className="flex items-center justify-between"><div><p className="text-[13px] font-black">지우 님과의 데이트 신청 · 애프터</p><p className="text-[11px] text-[var(--muted)]">첫 만남은 데이트 신청, 2번째부터 애프터 · 3번 만나면 연애 시작</p></div><span className="text-[13px] font-black text-[var(--accent)]">{afterCount} / 3</span></div><div className="mt-3 flex gap-2">{[1,2,3].map(n => <div key={n} className={`h-2 flex-1 rounded-full ${n<=afterCount?'bg-[var(--accent)]':'bg-[var(--line)]'}`}/>)}</div><div className="mt-2 flex justify-between text-[10px] font-bold text-[var(--muted)]"><span>1차 데이트</span><span>2차 애프터</span><span>3차 애프터</span></div>{afterCount>=3 ? <div className="mt-4 rounded-2xl bg-[#FFF1EB] p-3 text-[12px] font-bold text-[var(--accent)]">3번째 애프터 완료! 이제 두 분의 선택만 남았어요.</div> : <p className="mt-3 text-[12px] text-[var(--muted)]">다음 만남이 {3-afterCount}번 남았어요. 서두르지 않아도 돼요.</p>}</div>
                  <button onClick={()=>setView('request')} className="mt-4 w-full rounded-[22px] border border-[var(--line)] bg-[var(--surface)] p-4 text-left shadow-sm"><div className="flex items-center justify-between"><span className="rounded-full bg-[#FFF1EB] px-2.5 py-1 text-[11px] font-black text-[var(--accent)]">새로운 데이트 신청{isForeign && langTrans ? ` · ${langTrans.dateRequest}` : ''}</span><span className="flex items-center gap-1 text-[11px] font-bold text-[var(--muted)]">23시간 남음 <ChevronRight size={14}/></span></div><div className="mt-3 flex items-center gap-3"><div className="flex h-12 w-12 items-center justify-center rounded-full text-lg font-black text-white" style={{background:'linear-gradient(135deg,#A8C4A0,#6E9A7E)'}}>서</div><div><p className="text-[15px] font-black">서연 · 27 · 연남</p><p className="text-[12px] text-[var(--muted)]">11/20 목 19:00 · 성수 카페 제안</p></div></div><p className="mt-3 rounded-xl bg-[var(--bg)] p-3 text-[12px] leading-relaxed">“산책하면서 대화 나누는 시간을 좋아해요.”</p></button>
                  <h3 className="mt-6 text-[16px] font-black">오늘 할 일</h3><div className="mt-3 space-y-2.5">
                    <button onClick={()=>{setTab('recommend');}} className="flex w-full items-center gap-3 rounded-2xl bg-[var(--surface)] p-4 text-left shadow-sm"><span className="rounded-xl bg-[var(--sage-bg)] p-2.5">✨</span><span className="flex-1"><span className="block text-[14px] font-black">{bi('오늘의 추천 6명 확인하기', 'todayRec')}</span><span className="text-[11px] text-[var(--muted)]">자정에 새로고침돼요</span></span><ChevronRight size={16} className="text-[var(--muted)]"/></button>
                    <button onClick={()=>setView('feedback')} className="flex w-full items-center gap-3 rounded-2xl bg-[var(--surface)] p-4 text-left shadow-sm"><span className="rounded-xl bg-[#FFF1EB] p-2.5">☀️</span><span className="flex-1"><span className="block text-[14px] font-black">어제 애프터 피드백 남기기</span><span className="text-[11px] text-[var(--muted)]">2차 애프터 · 다음날 아침 9시에 물어봐요</span></span><ChevronRight size={16} className="text-[var(--muted)]"/></button>
                    <button onClick={()=>setView('share')} className="flex w-full items-center gap-3 rounded-2xl bg-[var(--surface)] p-4 text-left shadow-sm"><span className="rounded-xl bg-[#FFF6E6] p-2.5">🛡️</span><span className="flex-1"><span className="block text-[14px] font-black">지인에게 일정 공유하기</span><span className="text-[11px] text-[var(--muted)]">1회성 위치 인증으로 안전하게</span></span><ChevronRight size={16} className="text-[var(--muted)]"/></button>
                  </div>
                </div>
              )}

              {tab === 'recommend' && (
                <div className="px-5 pt-3">
                  <div className="flex items-end justify-between"><div><p className="text-[11px] font-black tracking-widest text-[var(--accent)]">TODAY · 11/18</p><h2 className="mt-1 text-[24px] font-black leading-tight">{bi('오늘의 추천 6명', 'todayRec')}</h2></div><span className="rounded-full bg-[var(--surface)] px-3 py-1.5 text-[11px] font-bold text-[var(--muted)] shadow-sm">자정 새로고침</span></div>
                  {isForeign && <div className="mt-3 flex items-center justify-between gap-2 rounded-[16px] bg-[var(--sage-bg)] p-3"><p className="flex items-center gap-2 text-[11px] font-black"><Globe size={14} className="text-[#6E9A7E]" />선택한 국적에 맞게 언어가 자동 번역돼요 · {LANG_LABEL[uiLang]}</p><div className="flex shrink-0 gap-1"><button onClick={()=>setUiLang('ko')} className={`rounded-full px-2.5 py-1 text-[11px] font-black ${uiLang==='ko' ? 'bg-[var(--accent)] text-white' : 'bg-[var(--surface)]'}`}>한국어</button><button onClick={()=>setUiLang('en')} className={`rounded-full px-2.5 py-1 text-[11px] font-black ${uiLang==='en' ? 'bg-[var(--accent)] text-white' : 'bg-[var(--surface)]'}`}>English</button></div></div>}
                  <div className="mt-4 rounded-[18px] border border-[var(--line)] bg-[var(--surface)] p-3"><p className="text-[12px] font-black">인증 완료끼리 / 미인증끼리만 추천돼요</p><p className="mt-1 text-[11px] leading-relaxed text-[var(--muted)]">초기에는 사람이 적어서 6명으로 시작해요. 내 인증 상태와 같은 그룹만 보여줘요.</p><div className="mt-3 flex gap-2"><button onClick={()=>{ setMatchPreview('mine'); resetDeck(); }} className={`flex-1 rounded-full py-2 text-[12px] font-black ${matchPreview==='mine'?'bg-[var(--accent)] text-white':'bg-[var(--bg)] text-[var(--ink)]'}`}>{isVerified ? '내 그룹 · 인증 완료' : '내 그룹 · 미인증'}</button><button onClick={()=>{ setMatchPreview('other'); resetDeck(); }} className={`flex-1 rounded-full py-2 text-[12px] font-black ${matchPreview==='other'?'bg-[var(--ink)] text-white':'bg-[var(--bg)] text-[var(--ink)]'}`}>다른 그룹 미리보기</button></div>{matchPreview==='mine' ? <p className="mt-2 text-center text-[11px] font-black text-[var(--accent)]">{isVerified ? '인증 완료끼리 매칭 중' : '미인증끼리 매칭 중'}</p> : <p className="mt-2 text-center text-[11px] font-bold text-[var(--muted)]">다른 그룹 미리보기 · 실제 추천은 내 그룹만 보여요</p>}</div>
                  <div className="no-scrollbar -mx-5 mt-4 flex gap-2 overflow-x-auto px-5 pb-1"><button onClick={()=>{setStage('ideal');}} className="shrink-0 rounded-full border border-[var(--accent)] bg-[#FFF1EB] px-3 py-1.5 text-[11px] font-black text-[var(--accent)]">만나고 싶은 상대: {desiredGender} · 바꾸기</button>{[ageRange, ...areas, ...types.slice(0,1), ...times].map(c => <span key={c} className="shrink-0 rounded-full border border-[var(--line)] bg-[var(--surface)] px-3 py-1.5 text-[11px] font-bold">{c}</span>)}<button onClick={()=>{setStage('ideal');}} className="shrink-0 rounded-full bg-[var(--ink)] px-3 py-1.5 text-[11px] font-bold text-white">조건 바꾸기</button></div>
                  <div className="mt-4">
                    <div className="flex items-center justify-between"><p className="text-[15px] font-black">{deckFinished ? `${deckTotal} / ${deckTotal}` : `${deckIndex + 1} / ${deckTotal}`}</p><p className="text-[12px] font-bold text-[var(--muted)]">{deckFinished ? '남은 추천 0명' : `남은 추천 ${deckRemaining}명`}</p></div>
                    <div className="mt-2 flex gap-1.5">{visibleProfiles.map((pp, i) => <span key={pp.id} className={`h-1.5 flex-1 rounded-full ${i < deckIndex ? 'bg-[var(--line)]' : i === deckIndex ? 'bg-[var(--accent)]' : 'bg-[var(--line)] opacity-50'}`} />)}</div>
                    {deckFinished ? (
                      <div className="mt-4 rounded-[28px] border border-[var(--line)] bg-[var(--surface)] p-6 text-center shadow-sm"><span className="text-4xl">✨</span><h3 className="mt-3 text-[20px] font-black">오늘 추천을 다 봤어요</h3><p className="mt-1 text-[13px] leading-relaxed text-[var(--muted)]">오늘의 추천 {deckTotal}명을 모두 확인했어요.<br/>자정에 새로운 추천이 열려요.</p><button onClick={resetDeck} className="mt-5 w-full rounded-2xl bg-[var(--accent)] py-4 text-[15px] font-black text-white">다시 보기</button><p className="mt-2 text-[11px] text-[var(--muted)]">처음 카드부터 다시 볼 수 있어요.</p></div>
                    ) : deckCurrent && (
                      <>
                        <div className="relative mt-4 h-[430px]">
                          {visibleProfiles.slice(deckIndex + 1, deckIndex + 3).map((next, i) => <div key={next.id} aria-hidden="true" className="absolute inset-0 overflow-hidden rounded-[28px] border border-[var(--line)] bg-[var(--surface)] shadow-sm" style={{ transform: `translateY(${(i + 1) * 12}px) scale(${0.95 - i * 0.04})`, opacity: 0.65 - i * 0.2, zIndex: 1 - i }}><div className="flex h-[230px] items-center justify-center text-[64px] font-black text-white" style={{ background: next.grad }}>{next.initial}</div><div className="p-4"><p className="text-[18px] font-black">{next.name} · {next.age}</p><p className="mt-1 text-[12px] text-[var(--muted)]">{next.area} · {next.job}</p></div></div>)}
                          <article onPointerDown={(e) => { if (exiting) return; setDragging(true); dragStartX.current = e.clientX; dragMoved.current = false; }} onPointerMove={(e) => { if (!dragging || exiting) return; const dx = e.clientX - dragStartX.current; if (Math.abs(dx) > 8) dragMoved.current = true; setDragX(dx); }} onPointerUp={(e) => { if (!dragging) return; setDragging(false); const dx = e.clientX - dragStartX.current; if (dx > 110) swipeDeck('right', deckCurrent); else if (dx < -110) swipeDeck('left', deckCurrent); else setDragX(0); }} onPointerCancel={() => { setDragging(false); setDragX(0); }} onClick={() => { if (dragMoved.current || exiting) { dragMoved.current = false; return; } openProfile(deckCurrent, 'recommend'); }} className="absolute inset-0 z-10 cursor-grab select-none overflow-hidden rounded-[28px] border border-[var(--line)] bg-[var(--surface)] shadow-xl active:cursor-grabbing" style={{ transform: `translateX(${dragX}px) rotate(${dragX * 0.05}deg)`, transition: dragging ? 'none' : 'transform 0.25s ease', touchAction: 'pan-y' }}>
                            <div className="relative flex h-[236px] flex-col items-center justify-center text-white" style={{ background: deckCurrent.grad }}><span className="absolute left-4 top-4 rounded-full bg-black/25 px-3 py-1.5 text-[11px] font-black">프로필 사진 · 플레이스홀더</span><span className="flex h-[104px] w-[104px] items-center justify-center rounded-full border-4 border-white/80 text-[48px] font-black shadow-lg">{deckCurrent.initial}</span>{deckCurrent.faceVerified && <span className="mt-4 flex items-center gap-1.5 rounded-full bg-white px-3 py-1.5 text-[11px] font-black text-[#2B5A3E]"><BadgeCheck size={13}/>얼굴 인증 완료</span>}</div>
                            {dragX > 24 && <span className="pointer-events-none absolute left-4 top-4 z-20 -rotate-12 rounded-xl border-2 border-[#6E9A7E] bg-white/90 px-3 py-1.5 text-[14px] font-black text-[#4F7A5D]" style={{ opacity: Math.min(1, dragX / 110) }}>데이트 신청하기 →</span>}
                            {dragX < -24 && <span className="pointer-events-none absolute right-4 top-4 z-20 rotate-12 rounded-xl border-2 border-[var(--muted)] bg-white/90 px-3 py-1.5 text-[14px] font-black text-[var(--muted)]" style={{ opacity: Math.min(1, -dragX / 110) }}>← 다음에 보기</span>}
                            <div className="p-5"><div className="flex flex-wrap items-center gap-2"><h3 className="text-[22px] font-black leading-none">{deckCurrent.name} · {deckCurrent.age}</h3><span className={`rounded-full px-2.5 py-1 text-[10px] font-black ${deckCurrent.verified ? 'bg-[var(--sage-bg)] text-[#4F7A5D]' : 'bg-[#FFF6E6] text-[#9A6A1A]'}`}>{deckCurrent.badge}</span></div><p className="mt-1.5 text-[12px] text-[var(--muted)]">{deckCurrent.area} · {deckCurrent.job}</p><p className="mt-3 text-[14px] font-bold leading-relaxed">{deckCurrent.introByLang[uiLang]}</p>{deckCurrent.origLang !== uiLang && <p className="mt-1.5 flex items-center gap-1 text-[11px] font-black text-[#4F7A5D]"><Languages size={12}/>자동 번역됨 · 원문은 프로필에서 볼 수 있어요</p>}<p className="mt-3 text-[11px] font-black text-[var(--muted)]">만날 수 있는 시간</p><div className="mt-1.5 flex flex-wrap gap-1.5">{deckCurrent.dates.map(d => <span key={d} className="rounded-full bg-[var(--bg)] px-2.5 py-1 text-[11px] font-bold">{d}</span>)}</div><p className="mt-3 text-center text-[11px] font-bold text-[var(--accent)]">카드를 눌러 프로필 자세히 보기</p></div>
                          </article>
                        </div>
                        <div className="mt-4 flex gap-2"><button onClick={() => swipeDeck('left', deckCurrent)} className="flex-1 rounded-2xl border-2 border-[var(--line)] bg-[var(--surface)] py-4 text-[15px] font-black">✕ 다음에 보기</button><button onClick={() => swipeDeck('right', deckCurrent)} className={`flex-1 rounded-2xl py-4 text-[15px] font-black ${applied.includes(deckCurrent.id) ? 'bg-[var(--sage-bg)] text-[#4F7A5D]' : 'bg-[var(--accent)] text-white'}`}>{applied.includes(deckCurrent.id) ? '신청 완료 · 다음으로' : '♥ 데이트 신청하기'}</button></div>
                        <p className="mt-2 text-center text-[11px] leading-relaxed text-[var(--muted)]">카드를 좌우로 밀거나 아래 버튼을 눌러 보세요.<br/>카드를 누르면 프로필 자세히 보기로 이동해요.</p>
                      </>
                    )}
                  </div>
                  <p className="mt-4 text-center text-[11px] text-[var(--muted)]">첫 만남은 데이트 신청이에요. 신청은 상대에게만 전달돼요. 거절해도 서로에게 표시되지 않아요.</p>
                </div>
              )}

              {tab === 'calendar' && (
                <div className="px-5 pt-3">
                  <div className="flex items-end justify-between"><h2 className="text-[24px] font-black">11월 캘린더</h2><span className="text-[12px] font-bold text-[var(--muted)]">2026년 11월</span></div>
                  <div className="mt-4 rounded-[24px] border border-[var(--line)] bg-[var(--surface)] p-4 shadow-sm"><div className="grid grid-cols-7 gap-1 text-center text-[11px] font-bold text-[var(--muted)]">{['일','월','화','수','목','금','토'].map(d => <span key={d} className="py-1">{d}</span>)}</div><div className="grid grid-cols-7 gap-1">{calendar.map((d,i) => <div key={i} className={`flex aspect-square flex-col items-center justify-center rounded-xl text-[13px] font-bold ${d===19?'bg-[var(--accent)] text-white':d && marked[d]?'bg-[#FFF1EB] text-[var(--accent)]':d?'bg-[var(--bg)]':'text-transparent'}`}>{d||'·'}{d && marked[d] && <span className={`mt-0.5 text-[8px] ${d===19?'text-white':'text-[var(--accent)]'}`}>{marked[d]}</span>}</div>)}</div></div>
                    <div className="mt-3 flex items-start gap-2 rounded-[18px] bg-[#2B2622] p-4 text-[12px] leading-relaxed text-white"><span className="text-base">⚠️</span><span><b>노쇼 시 즉시 계정 일시정지</b><br/>만남이 어려우면 전날까지 미리 취소해 주세요. 도착하면 1회성 위치 인증으로 만나요.</span></div>
                  <h3 className="mt-5 text-[16px] font-black">다가오는 데이트 신청 · 애프터</h3><p className="mt-1 text-[12px] text-[var(--muted)]">전날까지 계정당 3회까지 취소 가능 (남은 취소 {cancelsLeft}회)</p>
                  <div className="mt-3 space-y-3">{upcoming.map(u => { const cancelled = cancelledIds.includes(u.id); const met = metIds.includes(u.id); const isSeoyeon = u.id === 102; const profileId = u.id === 101 ? 1 : u.id === 102 ? 2 : 4; return <div key={u.id} className="rounded-[20px] border border-[var(--line)] bg-[var(--surface)] p-4"><div className="flex items-center justify-between"><span className="text-[12px] font-black" style={{color:u.color}}>{u.date}</span><span className="rounded-full bg-[var(--bg)] px-2.5 py-1 text-[11px] font-bold">{cancelled?'취소됨':u.status}</span></div><button onClick={()=>openProfileById(profileId, 'calendar')} className="mt-2 flex w-full items-center gap-2 text-left"><p className="text-[16px] font-black">{u.partner}</p><span className="rounded-full bg-[#FFF1EB] px-2 py-0.5 text-[10px] font-black text-[var(--accent)]">{u.kind}</span><span className="ml-auto flex items-center gap-1 text-[11px] font-bold text-[var(--accent)]">프로필 보기 <ChevronRight size={13}/></span></button><p className="mt-0.5 flex items-center gap-1 text-[12px] text-[var(--muted)]"><MapPin size={13}/>{u.place}</p><button onClick={()=>openProfileById(profileId, 'calendar')} className="mt-2 w-full rounded-xl border border-[var(--line)] py-2.5 text-[12px] font-bold">상대 프로필 자세히 보기</button>{isSeoyeon ? (<div className="mt-3 rounded-2xl bg-[var(--bg)] p-3"><p className="flex items-center gap-2 text-[13px] font-black"><Palette size={15} className="text-[var(--accent)]"/>{dressConfirmed ? dressShort : '드레스코드: 아직 정해지지 않았어요'}</p>{dressConfirmed ? <p className="mt-1 flex items-center gap-1 text-[12px] font-bold text-[#4F7A5D]"><Check size={13}/>양쪽 모두 동의했어요</p> : <button onClick={()=>setView('dresscode')} className="mt-2 w-full rounded-xl bg-[var(--accent)] py-2.5 text-[13px] font-black text-white">드레스코드 정하기</button>}<div className="mt-3 border-t border-[var(--line)] pt-3"><div className="flex items-center justify-between gap-2"><p className="flex items-center gap-1.5 text-[12px] font-black"><Vibrate size={14} className="text-[var(--accent)]"/>근접 진동 알림</p><button onClick={()=>{ const next=!proximityOn; setProximityOn(next); showToast(next?'근접 진동 알림을 켰어요':'근접 진동 알림을 껐어요'); }} className={`shrink-0 rounded-full px-3 py-1.5 text-[12px] font-black ${proximityOn ? 'bg-[var(--accent)] text-white' : 'bg-[var(--surface)] text-[var(--muted)]'}`}>{proximityOn ? '켜짐' : '꺼짐'}</button></div><p className="mt-2 text-[11px] leading-relaxed text-[var(--muted)]">근접 진동 알림은 양쪽 모두 동의했을 때만, 만남 30분 전부터 100m 이내에서 1회 울려요</p></div></div>) : (<div className="mt-3 rounded-2xl bg-[var(--bg)] p-3"><p className="text-[12px] font-bold text-[var(--muted)]">드레스코드: 이 만남은 드레스코드 준비 화면에서 정해요</p><button onClick={()=>setView('dresscode')} className="mt-2 w-full rounded-xl border border-[var(--line)] py-2.5 text-[12px] font-bold">만남 준비 - 드레스코드 보기</button></div>)} {verifiedIds.includes(u.id) ? <p className="mt-3 rounded-xl bg-[var(--sage-bg)] p-3 text-center text-[13px] font-black text-[#4F7A5D]">만남 인증 완료 ✓ · 두 분 위치가 120m 이내에서 확인됐어요</p> : <button disabled={cancelled} onClick={()=>{ if(cancelled) return; startArrival(u.id); }} className="mt-3 w-full rounded-xl bg-[var(--accent)] py-3.5 text-[15px] font-black text-white">도착했어요</button>}<p className="mt-2 text-center text-[11px] leading-relaxed text-[var(--muted)]">도착하면 위치를 1회만 확인해요. 계속 추적하지 않아요.</p><button disabled={cancelled} onClick={()=>{ setNoshowForId(u.id); setReportKind('noshow'); setNoshowReason(''); setNoshowSubmitted(false); setDisputeMode(false); openReport(profileId, { returnTab: 'calendar', preselect: '노쇼·연락 두절' }); }} className="mt-2 w-full rounded-xl border border-[var(--line)] py-2.5 text-[13px] font-bold">안 왔어요 · 노쇼 신고하기</button><button disabled={cancelled||cancelsLeft===0} onClick={()=>cancelAfter(u.id)} className="mt-2 w-full rounded-xl border border-[var(--line)] py-2.5 text-[13px] font-bold">{cancelled?'취소 완료':cancelsLeft===0?'취소 횟수 소진':'일정 취소하기'}</button></div>; })}</div>
                  <button onClick={()=>setView('feedback')} className="mt-4 w-full rounded-2xl bg-[var(--sage-bg)] py-3.5 text-[14px] font-black text-[#4F7A5D]">어제 애프터 피드백 남기기</button>
                </div>
              )}

              {tab === 'my' && (
                <div className="px-5 pt-3">
                  <div className="flex items-center gap-4"><div className="flex h-16 w-16 items-center justify-center rounded-full bg-[var(--accent)] text-2xl font-black text-white">나</div><div><h2 className="text-[22px] font-black">나의 애프터</h2><p className="text-[12px] text-[var(--muted)]">서울 · {isVerified ? '인증 완료 회원' : '미인증 회원'}</p><span className="mt-1.5 inline-flex items-center gap-1 rounded-full bg-[var(--sage-bg)] px-2.5 py-1 text-[11px] font-black text-[#4F7A5D]"><ShieldCheck size={12}/>{authMethodLabel}</span></div></div>
                  <div className="mt-5 rounded-[22px] border border-[var(--line)] bg-[var(--surface)] p-4"><div className="flex items-center justify-between"><p className="font-black">인증 상태</p><span className={`flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-black ${isVerified ? 'bg-[var(--sage-bg)] text-[#4F7A5D]' : 'bg-[#FFF6E6] text-[#9A6A1A]'}`}><BadgeCheck size={13}/>{isVerified ? '인증 완료' : '미인증'}</span></div><div className="mt-3 space-y-2 text-[13px]"><div className="flex justify-between"><span className="text-[var(--muted)]">인증 방식</span><b>{authMethodLabel}</b></div><div className="flex justify-between"><span className="text-[var(--muted)]">소속 인증</span><b>{verifyLabel}</b></div><div className="flex justify-between"><span className="text-[var(--muted)]">얼굴 인증</span><b>{faceVerified ? '얼굴 인증 완료' : '얼굴 인증 전'}</b></div><div className="flex justify-between"><span className="text-[var(--muted)]">남은 취소 횟수</span><b className="text-[var(--accent)]">{cancelsLeft}회</b></div></div>{!isVerified && <><p className="mt-3 rounded-xl bg-[#FFF6E6] p-3 text-[11px] leading-relaxed text-[var(--muted)]">인증 안 한 사람은 인증 안 한 사람끼리만 추천돼요. 인증하면 인증 완료끼리 추천돼요.</p><button onClick={()=>{ setStage('onboarding'); setOnStep(3); }} className="mt-3 w-full rounded-xl bg-[var(--accent)] py-3 text-[14px] font-black text-white">지금 인증하기</button></>}{!faceVerified && isVerified && <button onClick={()=>{ setStage('onboarding'); setOnStep(4); }} className="mt-3 w-full rounded-xl border border-[var(--accent)] py-3 text-[14px] font-black text-[var(--accent)]">얼굴 인증하기</button>}</div>
                  <div className="mt-4 rounded-[22px] border border-[var(--line)] bg-[var(--surface)] p-4"><div className="flex items-center justify-between gap-2"><p className="flex items-center gap-2 font-black"><Globe size={17} className="text-[var(--accent)]" />언어 / Language</p><span className="rounded-full bg-[var(--sage-bg)] px-2.5 py-1 text-[11px] font-black text-[#4F7A5D]">{isForeign ? '국적 기반 자동 선택' : '한국어'}</span></div><p className="mt-1 text-[12px] leading-relaxed text-[var(--muted)]">{isForeign ? `선택한 국적(${foreignCountry})에 맞게 언어가 자동 번역돼요. 현재 언어는 ${LANG_LABEL[uiLang]}예요.` : '국적이 대한민국이라 한국어로 보여요. 외국인 국적을 선택하면 국적에 맞게 자동 번역돼요.'}</p><div className="mt-3 flex flex-wrap gap-2">{LANGUAGE_OPTIONS.map(l => <button key={l.id} onClick={()=>{ setUiLang(l.id); showToast(`표시 언어를 ${l.label}(으)로 바꿨어요`); }} className={`rounded-full px-3.5 py-2 text-[12px] font-black ${uiLang===l.id ? 'bg-[var(--accent)] text-white' : 'bg-[var(--bg)] text-[var(--ink)]'}`}>{l.label}</button>)}</div><div className="mt-3 flex gap-2 rounded-xl bg-[var(--bg)] p-3"><button onClick={()=>{ setUiLang('ko'); showToast('표시 언어를 한국어로 바꿨어요'); }} className={`flex-1 rounded-lg py-2 text-[12px] font-black ${uiLang==='ko' ? 'bg-[var(--ink)] text-white' : 'bg-[var(--surface)]'}`}>한국어</button><button onClick={()=>{ setUiLang('en'); showToast('표시 언어를 English로 바꿨어요'); }} className={`flex-1 rounded-lg py-2 text-[12px] font-black ${uiLang==='en' ? 'bg-[var(--ink)] text-white' : 'bg-[var(--surface)]'}`}>English</button></div><p className="mt-2 text-[11px] leading-relaxed text-[var(--muted)]">데모용 한국어 ↔ English 전환 · 미리보기: {bi('데이트 신청하기', 'dateRequest')}</p>{isForeign && <button onClick={()=>{ const found = FOREIGN_COUNTRIES.find(c=>c.id===foreignCountry); if (found) { setUiLang(found.lang); showToast(`${foreignCountry} 기준으로 자동 번역 언어로 되돌렸어요`); } }} className="mt-2 w-full rounded-xl border border-[var(--line)] py-2.5 text-[12px] font-bold">국적 기준 자동 언어로 되돌리기</button>}</div>
                  <div className="mt-4 rounded-[22px] border border-[var(--line)] bg-[var(--surface)] p-4"><div className="flex items-center justify-between"><p className="font-black">성별 · 만나고 싶은 상대</p><span className="flex items-center gap-1 rounded-full bg-[var(--bg)] px-2.5 py-1 text-[11px] font-black text-[var(--muted)]"><Lock size={12}/>내 성별 수정 불가</span></div><p className="mt-1 text-[12px] leading-relaxed text-[var(--muted)]">이 정보는 매칭에만 사용돼요.</p><div className="mt-3 flex items-center justify-between rounded-xl bg-[var(--bg)] p-3"><p className="text-[13px] font-black">내 성별 · {profileGenderLabel}</p><span className="flex items-center gap-1 text-[11px] font-black text-[var(--muted)]"><Lock size={12}/>수정 불가</span></div><p className="mt-2 flex items-center gap-1 text-[11px] font-bold text-[var(--ink)]"><Lock size={12}/>{genderLockMessage}</p><p className="mt-1 text-[11px] leading-relaxed text-[var(--muted)]">{genderLockNote}</p><p className="mt-3 text-[12px] font-black">만나고 싶은 상대의 성별</p><div className="mt-2 flex flex-wrap gap-2">{(['남성','여성','모두'] as DesiredGender[]).map(v => <Chip key={v} active={desiredGender===v} onClick={()=>{ setDesiredGender(v); showToast(`만나고 싶은 상대를 ${v}(으)로 바꿨어요`); }}>{v}</Chip>)}</div><p className="mt-3 rounded-xl bg-[var(--sage-bg)] p-3 text-[12px] font-bold">{profilePreview}</p></div>
                  <h3 className="mt-6 text-[16px] font-black">데이트 신청 · 애프터 기록</h3><p className="mt-1 text-[12px] text-[var(--muted)]">기록을 누르면 지우 님 프로필을 다시 볼 수 있어요.</p><div className="mt-3 space-y-2.5">{[{n:'1차 데이트 완료',p:'지우 · 성수 카페',d:'11/05 수 · 완료'},{n:'2차 애프터',p:'지우 · 연남 산책',d:'11/12 수 · 완료'},{n:'3차 애프터',p:'지우 · 전시 관람',d:'11/19 수 · 예정'}].map((h,i) => <button key={h.n} onClick={()=>openProfileById(1, 'my')} className="flex w-full items-center gap-3 rounded-2xl bg-[var(--surface)] p-4 text-left"><span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-[13px] font-black ${i<2?'bg-[var(--sage-bg)] text-[#4F7A5D]':'bg-[#FFF1EB] text-[var(--accent)]'}`}>{i+1}</span><span className="flex-1"><span className="block text-[14px] font-black">{h.n}</span><span className="block text-[12px] text-[var(--muted)]">{h.p}</span></span><span className="flex items-center gap-1 text-[11px] font-bold text-[var(--muted)]">{h.d} <ChevronRight size={13}/></span></button>)}</div>
                  <h3 className="mt-6 text-[16px] font-black">안전 기능</h3><div className="mt-3 space-y-2.5">
                    <button onClick={()=>setView('share')} className="flex w-full items-center gap-3 rounded-2xl bg-[var(--surface)] p-4 text-left"><span className="text-xl">🛡️</span><span className="flex-1 text-[14px] font-bold">지인에게 일정 공유하기</span><ChevronRight size={16} className="text-[var(--muted)]"/></button>
                    <button onClick={()=>openReport(1, { returnTab: 'my' })} className="flex w-full items-center gap-3 rounded-2xl bg-[var(--surface)] p-4 text-left"><span className="text-xl">🚨</span><span className="flex-1 text-[14px] font-bold">신고하기</span><ChevronRight size={16} className="text-[var(--muted)]"/></button>
                    <button onClick={()=>setView('code')} className="flex w-full items-center gap-3 rounded-2xl bg-[var(--surface)] p-4 text-left"><span className="text-xl">🔑</span><span className="flex-1 text-left"><span className="block text-[14px] font-bold">만남 코드 · 드레스코드 보기</span><span className="text-[11px] text-[var(--muted)]">{dressConfirmed ? `${dressColorDesc} + ${dressItemLabel}` : '코드 A-4821 · 신호를 정해 보세요'} · 진동 {proximityOn ? '켜짐' : '꺼짐'}</span></span><ChevronRight size={16} className="text-[var(--muted)]"/></button>
                  </div>
                  <p className="mt-4 rounded-2xl bg-[var(--bg)] p-3 text-center text-[11px] leading-relaxed text-[var(--muted)]">전화번호는 절대 공개되지 않아요.<br/>만남은 만남 코드로만 연결돼요.</p>
                  <div className="mt-6 rounded-[22px] border border-[var(--line)] bg-[var(--surface)] p-4">
                    <div className="flex items-center justify-between gap-2"><h3 className="flex items-center gap-2 text-[16px] font-black"><Database size={17} className="text-[var(--accent)]" />백엔드 연결</h3><span className={`shrink-0 rounded-full px-2.5 py-1 text-[11px] font-black ${backendStatus === 'connected' ? 'bg-[var(--sage-bg)] text-[#4F7A5D]' : backendStatus === 'checking' ? 'bg-[#FFF6E6] text-[#9A6A1A]' : backendStatus === 'failed' ? 'bg-[#FFF1EB] text-[#C94A30]' : 'bg-[var(--bg)] text-[var(--muted)]'}`}>{backendStatus === 'connected' ? '연결 성공' : backendStatus === 'checking' ? '연결 중' : backendStatus === 'failed' ? '연결 실패' : '미연결'}</span></div>
                    <p className="mt-2 text-[12px] leading-relaxed text-[var(--muted)]">이 앱은 키를 입력하지 않아도 되는 내장 백엔드 연결을 사용해요. 어떤 키도 이 브라우저나 코드에 저장하지 않아요. service_role 키는 절대 입력하지 마세요. 이 화면에서는 키 입력 칸을 두지 않아요.</p>
                    <p className="mt-2 rounded-xl bg-[var(--bg)] p-3 text-[12px] font-bold leading-relaxed">{backendMessage}</p>
                    <p className="mt-2 text-[11px] font-bold text-[var(--muted)]">마지막 확인 · {backendLastChecked || '아직 없음'} · 미연결이어도 데모 모드로 계속 사용할 수 있어요</p>
                    <div className="mt-3 grid grid-cols-3 gap-2"><button disabled={backendBusy} onClick={testBackendConnection} className="rounded-xl bg-[var(--accent)] py-3 text-[12px] font-black text-white disabled:opacity-50">{backendBusy ? '확인 중…' : '연결 테스트'}</button><button disabled={backendBusy} onClick={checkBackendTables} className="rounded-xl bg-[var(--ink)] py-3 text-[12px] font-black text-white disabled:opacity-50">{backendBusy ? '확인 중…' : '테이블 확인'}</button><button disabled={backendBusy} onClick={disconnectBackend} className="rounded-xl border border-[var(--line)] py-3 text-[12px] font-black disabled:opacity-50">연결 해제</button></div>
                    {backendStatus === 'failed' && <ul className="mt-3 space-y-1 rounded-xl bg-[#FFF1EB] p-3 text-[11px] leading-relaxed text-[#1A1A1A]"><li>• 데모 모드에서는 이 메시지가 나와도 화면을 계속 볼 수 있어요.</li><li>• 별도 백엔드를 쓴다면, 배포 환경에 연결 정보가 제대로 설정됐는지 확인해 주세요.</li><li>• 필요한 6개 컬렉션(users, profiles, date_requests, calendar_events, reports, dress_codes)이 있는지 확인해 주세요.</li></ul>}
                    {backendTables.length > 0 && <div className="mt-3 overflow-hidden rounded-xl border border-[var(--line)]"><div className="grid grid-cols-3 bg-[var(--bg)] px-3 py-2 text-[11px] font-black"><span>컬렉션</span><span>상태</span><span>결과</span></div>{backendTables.map(t => <div key={t.name} className="grid grid-cols-3 border-t border-[var(--line)] px-3 py-2 text-[11px]"><span className="font-bold">{t.name}</span><span className={`font-black ${t.status === 'OK' ? 'text-[#4F7A5D]' : 'text-[#C94A30]'}`}>{t.status}</span><span className="text-[var(--muted)]">{t.detail}</span></div>)}</div>}
                    <div className="mt-4 rounded-2xl border border-[var(--line)] bg-[var(--bg)] p-4">
                      <div className="flex items-center justify-between gap-2"><h4 className="text-[14px] font-black">카카오 설정</h4><span className={`shrink-0 rounded-full px-2.5 py-1 text-[11px] font-black ${kakaoStatus === '연동준비됨' ? 'bg-[var(--sage-bg)] text-[#4F7A5D]' : kakaoStatus === '데모모드' ? 'bg-[#FFF6E6] text-[#9A6A1A]' : 'bg-white text-[var(--muted)]'}`}>{kakaoStatus}</span></div>
                      <p className="mt-1 text-[11px] leading-relaxed text-[var(--muted)]">카카오 로그인용 설정이에요. 키는 코드에 적지 않고, 저장하면 기록 API에 저장돼요.</p>
                      <label className="mt-3 block text-[12px] font-bold text-[var(--muted)]" htmlFor="kakao-key-mypage">REST API KEY</label>
                      <input id="kakao-key-mypage" value={kakaoKey} onChange={e => setKakaoKey(e.target.value)} placeholder="REST API 키를 입력해 주세요" autoComplete="off" className="mt-1.5 w-full rounded-xl border border-[var(--line)] bg-[var(--surface)] px-3 py-3 text-[13px] font-bold outline-none focus:border-[var(--accent)]" />
                      <label className="mt-3 block text-[12px] font-bold text-[var(--muted)]" htmlFor="kakao-redirect-mypage">Redirect URI</label>
                      <input id="kakao-redirect-mypage" value={kakaoRedirect} onChange={e => setKakaoRedirect(e.target.value)} placeholder="Redirect URI" autoComplete="off" className="mt-1.5 w-full rounded-xl border border-[var(--line)] bg-[var(--surface)] px-3 py-3 text-[13px] font-bold outline-none focus:border-[var(--accent)]" />
                      {kakaoProfile && <div className="mt-3 flex items-center gap-2 rounded-xl bg-[var(--surface)] p-3"><span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#FEE500] text-[14px] font-black text-[#1A1A1A]">{kakaoProfile.image}</span><div><p className="text-[12px] font-black">{kakaoProfile.nickname}</p><p className="text-[11px] text-[var(--muted)]">{kakaoProfile.email}</p></div></div>}
                      {kakaoOAuthUrl && <div className="mt-3 rounded-xl bg-[var(--surface)] p-3"><p className="break-all font-mono text-[11px] leading-relaxed">{kakaoOAuthUrl}</p><a href={kakaoOAuthUrl} target="_blank" rel="noopener" className="mt-2 block rounded-lg bg-[#FEE500] py-2.5 text-center text-[13px] font-black text-[#1A1A1A]">카카오 로그인 페이지 열기</a><p className="mt-1.5 text-[11px] leading-relaxed text-[var(--muted)]">실제 연동은 Vercel 배포 후 Redirect URI를 Kakao Developers에 등록해야 해요.</p></div>}
                      <button disabled={kakaoSaving} onClick={saveKakaoSettings} className="mt-3 w-full rounded-xl bg-[var(--ink)] py-3 text-[13px] font-black text-white disabled:opacity-50">{kakaoSaving ? '저장 중…' : '카카오 설정 저장하기'}</button>
                      <p className="mt-2 text-[11px] leading-relaxed text-[var(--muted)]">{kakaoSettingsMessage}</p>
                      <div className="mt-2 flex gap-2"><button onClick={() => { setKakaoModalOpen(true); setStage('login'); }} className="flex-1 rounded-xl border border-[var(--line)] bg-[var(--surface)] py-2.5 text-[12px] font-black">카카오 연결 안내 보기</button><button onClick={startKakaoDemo} className="flex-1 rounded-xl bg-[#FEE500] py-2.5 text-[12px] font-black text-[#1A1A1A]">데모 프로필 받기</button></div>
                    </div>
                    <button onClick={() => setShowBackendSnippet(v => !v)} className="mt-3 w-full rounded-xl border border-[var(--line)] py-2.5 text-[12px] font-black">{showBackendSnippet ? '코드 예시 닫기' : '실제 배포용 코드 예시 보기'}</button>
                    {showBackendSnippet && <div className="mt-3 rounded-xl bg-[#1A1A1A] p-3 text-white"><p className="text-[11px] font-black text-white">별도 Supabase를 직접 연결할 때의 참고 예시예요 · 이 앱은 키를 코드에 넣지 않아요</p><pre className="mt-2 overflow-x-auto whitespace-pre-wrap break-words font-mono text-[11px] leading-relaxed text-white">{`const supabaseUrl = 'YOUR_URL'
const supabaseKey = 'YOUR_PUBLISHABLE_KEY'`}</pre><p className="mt-2 text-[11px] leading-relaxed text-white/80">실제 Vercel 배포에서는 코드에 키를 직접 적지 말고 환경 변수 VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY를 사용하세요. service_role 키는 브라우저에 넣지 마세요.</p></div>}
                  </div>
                  <h3 className="mt-6 flex items-center gap-2 text-[16px] font-black"><Database size={17} className="text-[var(--accent)]" />로컬 데이터 미리보기</h3>
                  <div className="mt-3 rounded-[22px] border border-[var(--line)] bg-[var(--surface)] p-4"><p className="text-[13px] font-black">이 화면 세션 전용 미리보기</p><p className="mt-1 text-[12px] leading-relaxed text-[var(--muted)]">users · profiles · date_requests · calendar_events · reports · dress_codes 구조를 이 화면에서만 보여줘요. 서버나 기기에 저장되지 않고, 새로고침하면 초기화돼요.</p><div className="mt-3 flex gap-2"><button onClick={()=>{ setShowDevData(v=>!v); showToast(showDevData ? '개발자용 데이터 보기를 닫았어요' : '개발자용 데이터 보기를 열었어요'); }} className="flex-1 rounded-xl bg-[#1A1A1A] py-3 text-[13px] font-black text-white">{showDevData ? '개발자용 데이터 보기 닫기' : '개발자용 데이터 보기'}</button><button onClick={copyDevPreview} className="flex-1 rounded-xl border border-[var(--line)] py-3 text-[13px] font-black">미리보기 복사하기</button></div>{showDevData && <textarea ref={devPreviewRef} readOnly value={localTablesJson} rows={12} className="mt-3 w-full resize-none rounded-xl border border-[var(--line)] bg-[#1A1A1A] p-3 font-mono text-[11px] leading-relaxed text-white" aria-label="로컬 테이블 미리보기" />}{!confirmReset ? <button onClick={()=>setConfirmReset(true)} className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border-2 border-[#E85D3F] py-3 text-[13px] font-black text-[#C94A30]"><Trash2 size={15} />데이터 초기화</button> : <div className="mt-3 rounded-2xl bg-[#FFF1EB] p-3"><p className="text-[13px] font-black text-[#1A1A1A]">이 화면의 입력을 모두 처음 상태로 되돌릴까요?</p><p className="mt-1 text-[12px] leading-relaxed text-[#5A534D]">온보딩부터 다시 시작해요. 이 작업은 이 화면에서만 적용돼요.</p><div className="mt-3 flex gap-2"><button onClick={resetLocalData} className="flex-1 rounded-xl bg-[#C94A30] py-3 text-[13px] font-black text-white">네, 초기화하기</button><button onClick={()=>setConfirmReset(false)} className="flex-1 rounded-xl border border-[var(--line)] bg-white py-3 text-[13px] font-black text-[#1A1A1A]">취소</button></div></div>}<p className="mt-3 text-center text-[11px] font-bold text-[var(--muted)]">마지막 반영 · {localSavedAt} · 신고 {submittedReports.length}건 · 신청 {applied.length}건</p></div>
                </div>
              )}
            </div>
          )}

          {stage === 'main' && view === 'request' && (
            <div className="px-5 pb-8 pt-3">
              <button onClick={()=>setView('main')} className="flex items-center gap-1 text-[13px] font-bold text-[var(--muted)]"><ArrowLeft size={16}/>뒤로</button>
              <div className="mt-4"><SectionTitle kicker="DATE REQUEST" title="데이트 신청이 왔어요" sub="서연 님이 첫 만남을 제안했어요. 24시간 안에 답해 주세요." /></div>
              <div className="mt-5 overflow-hidden rounded-[24px] border border-[var(--line)] bg-[var(--surface)]"><div className="flex gap-4 p-5"><div className="flex shrink-0 flex-col items-center gap-1.5"><div className="flex h-20 w-16 items-center justify-center rounded-[18px] text-3xl font-black text-white" style={{background:'linear-gradient(135deg,#A8C4A0,#6E9A7E)'}}>서</div><span className="flex items-center gap-1 rounded-full bg-[var(--sage-bg)] px-2 py-1 text-[9px] font-black text-[#4F7A5D]"><BadgeCheck size={11}/>얼굴 인증 완료</span></div><div><h3 className="text-[19px] font-black">서연 · 27</h3><p className="text-[12px] text-[var(--muted)]">연남 · 브랜드 디자이너</p><span className="mt-1.5 inline-flex items-center gap-1 rounded-full bg-[var(--sage-bg)] px-2 py-0.5 text-[11px] font-black text-[#4F7A5D]"><BadgeCheck size={12}/>직장 인증</span><p className="mt-1.5 text-[11px] font-bold text-[var(--accent)]">첫 만남은 데이트 신청이에요</p></div></div><div className="space-y-3 border-t border-[var(--line)] px-5 py-4 text-[13px]"><div className="flex gap-3"><Clock size={16} className="text-[var(--accent)]"/><span><b>11/20 목 19:00</b> · 1시간 30분</span></div><div className="flex gap-3"><MapPin size={16} className="text-[var(--accent)]"/><span><b>성수 카페</b> · 조용한 2층 카페</span></div><div className="flex gap-3"><Coffee size={16} className="text-[var(--accent)]"/><span>산책 후 카페에서 이야기 나누고 싶어요.</span></div></div></div>
              <div className="mt-3 rounded-[18px] bg-[#FFF6E6] p-4 text-[12px] leading-relaxed"><b>⏰ 24시간 내 응답하지 않으면 자동 거절돼요</b><br/><span className="text-[var(--muted)]">일정 조율은 만남당 1회만 가능해요.</span></div>
              {requestStatus === 'waiting' && (<><button onClick={()=>{setRequestStatus('accepted'); setTab('calendar'); showToast('데이트 신청이 확정됐어요. 드레스코드를 정해 보세요.'); setView('dresscode');}} className="mt-4 w-full rounded-2xl bg-[var(--accent)] py-4 text-[16px] font-black text-white">{bi('수락하기', 'accept')}</button><button onClick={()=>setRequestStatus('reschedule')} className="mt-2 w-full rounded-2xl border-2 border-[var(--accent)] bg-[var(--surface)] py-3.5 text-[15px] font-black text-[var(--accent)]">일정 조율 신청</button><button onClick={()=>{setRequestStatus('declined'); showToast('정중히 거절했어요.'); setView('main');}} className="mt-2 w-full rounded-2xl bg-[var(--bg)] py-3.5 text-[14px] font-bold text-[var(--muted)]">거절하기</button></>)}
              {requestStatus === 'reschedule' && (<div className="mt-4 rounded-[20px] border border-[var(--line)] bg-[var(--surface)] p-4"><p className="text-[14px] font-black">대안 시간 2개를 제시해요</p><p className="mt-1 text-[12px] text-[var(--muted)]">만남당 조율은 1회만 가능해요.</p><div className="mt-3 grid grid-cols-2 gap-2">{['11/21 금 19:00','11/22 토 15:00'].map(d => <button key={d} onClick={()=>setRescheduleChoice(d)} className={`rounded-xl border px-2 py-3 text-[13px] font-bold ${rescheduleChoice===d?'border-[var(--accent)] bg-[#FFF1EB] text-[var(--accent)]':'border-[var(--line)]'}`}>{d}</button>)}</div><button onClick={()=>{ if(!rescheduleChoice) return showToast('대안 시간을 선택해 주세요'); showToast(`${rescheduleChoice} 대안을 보냈어요`); setView('main');}} className="mt-3 w-full rounded-xl bg-[var(--ink)] py-3.5 text-[14px] font-black text-white">조율 요청 보내기</button><button onClick={()=>setRequestStatus('waiting')} className="mt-2 w-full py-2 text-[12px] font-bold text-[var(--muted)]">다시 선택하기</button></div>)}
              {requestStatus === 'accepted' && <div className="mt-4 rounded-[20px] bg-[var(--sage-bg)] p-4 text-center"><p className="text-[13px] font-bold text-[#4F7A5D]">확정됐어요. 캘린더에서 확인할 수 있어요.</p><button onClick={()=>setView('dresscode')} className="mt-3 w-full rounded-xl bg-[var(--accent)] py-3 text-[14px] font-black text-white">만남 준비 - 드레스코드 정하기</button></div>}
              {requestStatus === 'declined' && <div className="mt-4 rounded-[20px] bg-[var(--bg)] p-4 text-center text-[13px] font-bold text-[var(--muted)]">거절이 전달됐어요.</div>}
            </div>
          )}

          {stage === 'main' && view === 'dresscode' && (
            <div className="min-h-full bg-[#FFF9F2] px-5 pb-8 pt-3 text-[#1A1A1A]">
              <button onClick={()=>{ setView('main'); setTab('calendar'); }} className="flex items-center gap-1 text-[13px] font-bold text-[var(--muted)]"><ArrowLeft size={16}/>캘린더로</button>
              <div className="mt-4"><SectionTitle kicker="MEETING PREP · DRESS CODE" title="만남 준비 - 드레스코드" sub="서연 님 · 11/20 목 19:00 · 성수 카페" /></div>
              <p className="mt-3 rounded-[18px] bg-white p-4 text-[13px] font-bold leading-relaxed text-[#1A1A1A] shadow-sm">서연 님 · 11/20 목 19:00 · 성수 카페 · 만남 코드 A-4821</p>
              <h2 className="mt-4 text-[22px] font-black leading-tight">서로 알아볼 수 있게<br/>드레스코드를 정해요</h2>
              <p className="mt-2 text-[13px] leading-relaxed text-[#1A1A1A]">서로 알아볼 수 있게 드레스코드를 정해요. 부담스럽지 않게 색깔 1개 + 소품 1개까지만 정해요.</p>
              <div className="mt-4 flex items-center justify-between rounded-[18px] bg-[var(--sage-bg)] px-4 py-3"><span className="text-[12px] font-black text-[#4F7A5D]">변경 가능 {dressChangesLeft}회 남음</span><span className={`rounded-full px-2.5 py-1 text-[11px] font-black ${dressStatus==='confirmed' ? 'bg-[#6E9A7E] text-white' : dressStatus==='proposed' ? 'bg-[#E9A44A] text-white' : 'bg-white text-[var(--muted)]'}`}>{dressStatus==='confirmed' ? '확정됨 ✓' : dressStatus==='proposed' ? '상대 응답 대기' : '선택 중'}</span></div>
              {dressPartnerNote && <p className="mt-3 rounded-[18px] bg-[#FFF1EB] p-3 text-[12px] font-bold leading-relaxed text-[var(--accent)]">{dressPartnerNote}</p>}
              <div className="mt-5 rounded-[22px] border border-[var(--line)] bg-[var(--surface)] p-4">
                <p className="text-[15px] font-black text-[#1A1A1A]">색깔 1개 선택</p>
                <p className="mt-1 text-[12px] font-bold text-[#5A534D]">상의 색깔을 하나만 골라 주세요.</p>
                <div className="mt-3 flex flex-wrap gap-2">{DRESS_COLORS.map(c => <button key={c.id} onClick={()=>{ if(dressStatus==='confirmed') return; setDressColor(c.id); setDressStatus('editing'); setDressCustomSaved(false); }} className={`flex items-center gap-2 rounded-full px-3.5 py-2.5 text-[13px] font-black ${dressColor===c.id ? 'select-card-selected text-[#C94A30]' : 'select-card'}`}><span className="h-4 w-4 rounded-full border border-black/10" style={{background:c.swatch}} />{c.label}{dressColor===c.id && <Check size={14}/>}</button>)}</div>
                  {dressColor==='custom' && (<div className="mt-3 rounded-[18px] bg-[#FFF0EB] p-3"><label htmlFor="dress-custom-color" className="block text-[12px] font-black text-[#1A1A1A]">직접 적기 · 색깔</label><div className="mt-2 flex items-center gap-2"><input id="dress-custom-color" type="text" inputMode="text" autoComplete="off" value={dressCustomColor} onChange={e=>{ setDressCustomColor(e.target.value.slice(0,20)); setDressCustomSaved(false); setDressColorError(''); }} onFocus={()=>setDressColorError('')} maxLength={20} placeholder="예: 노란색 계열" aria-label="드레스코드 색깔 직접 입력" aria-invalid={Boolean(dressColorError)} aria-describedby="dress-custom-color-error" className="min-w-0 flex-1 rounded-xl border-2 border-[#E85D3F] bg-white px-3 py-3 text-[14px] font-bold text-[#1A1A1A] outline-none focus:border-[#C94A30]" /><button type="button" onClick={saveDressColorCustom} className="shrink-0 rounded-xl bg-[#1A1A1A] px-4 py-3 text-[13px] font-black text-white">이 화면에 반영하기</button></div><div className="mt-1.5 flex items-center justify-between"><span className="text-[11px] font-bold text-[#5A534D]">{dressCustomColor.length} / 20</span><span className="text-[11px] font-bold text-[#5A534D]">최대 20자</span></div>{dressColorError && <p id="dress-custom-color-error" role="alert" className="mt-1 text-[12px] font-black text-[#C94A30]">직접 입력할 내용을 적어주세요</p>}{dressCustomSaved && dressCustomColorText && <p className="mt-2 text-[12px] font-black text-[#4F7A5D]">임시 반영됨 · 드레스코드: {dressCustomColorText} + {dressItemPlain}</p>}</div>)}
                <p className="mt-5 text-[15px] font-black text-[#1A1A1A]">소품 1개 선택</p>
                <p className="mt-1 text-[12px] font-bold text-[#5A534D]">손에 들고 있을 소품을 하나만 골라 주세요.</p>
                <div className="mt-3 grid grid-cols-2 gap-2">{DRESS_ITEMS.map(i => <button key={i.id} onClick={()=>{ if(dressStatus==='confirmed') return; setDressItem(i.id); setDressStatus('editing'); setDressCustomSaved(false); }} className={`rounded-2xl p-3 text-left ${dressItem===i.id ? 'select-card-selected' : 'select-card'}`}><span className="text-xl">{i.emoji}</span><span className="mt-1 block text-[13px] font-black text-[#1A1A1A]">{i.label}</span>{dressItem===i.id && <span className="mt-1 flex items-center gap-1 text-[11px] font-black text-[#C94A30]"><Check size={12}/>선택됨</span>}</button>)}</div>
                {dressItem==='custom' && (<div className="mt-3 rounded-[18px] bg-[#F0F5EE] p-3"><label htmlFor="dress-custom-item" className="block text-[12px] font-black text-[#1A1A1A]">직접 적기 · 소품</label><div className="mt-2 flex items-center gap-2"><input id="dress-custom-item" type="text" inputMode="text" autoComplete="off" value={dressCustomItem} onChange={e=>{ setDressCustomItem(e.target.value.slice(0,20)); setDressCustomSaved(false); setDressItemError(''); }} onFocus={()=>setDressItemError('')} maxLength={20} placeholder="예: 분홍색 우산" aria-label="드레스코드 소품 직접 입력" aria-invalid={Boolean(dressItemError)} aria-describedby="dress-custom-item-error" className="min-w-0 flex-1 rounded-xl border-2 border-[#6E9A7E] bg-white px-3 py-3 text-[14px] font-bold text-[#1A1A1A] outline-none focus:border-[#4F7A5D]" /><button type="button" onClick={saveDressItemCustom} className="shrink-0 rounded-xl bg-[#1A1A1A] px-4 py-3 text-[13px] font-black text-white">이 화면에 반영하기</button></div><div className="mt-1.5 flex items-center justify-between"><span className="text-[11px] font-bold text-[#5A534D]">{dressCustomItem.length} / 20</span><span className="text-[11px] font-bold text-[#5A534D]">최대 20자</span></div>{dressItemError && <p id="dress-custom-item-error" role="alert" className="mt-1 text-[12px] font-black text-[#C94A30]">직접 입력할 내용을 적어주세요</p>}{dressCustomSaved && dressCustomItemText && <p className="mt-2 text-[12px] font-black text-[#4F7A5D]">임시 반영됨 · 드레스코드: {dressColorPlain} + {dressCustomItemText}</p>}</div>)}
              </div>
              <p className="mt-3 rounded-[18px] bg-[#2B2622] p-4 text-[15px] font-black leading-relaxed text-white">실시간 미리보기 · {dressShort}</p>
              <div className="mt-4 overflow-hidden rounded-[24px] border border-[#F0D9C8] bg-white shadow-sm"><div className="bg-[#2B2622] p-4 text-white"><p className="text-[11px] font-black tracking-widest text-[#FFB59F]">LIVE PREVIEW · 실시간 미리보기</p><p className="mt-2 text-[16px] font-black leading-relaxed text-white">상대에게 보이는 내 드레스코드: {dressFull}</p><p className="mt-1 text-[13px] leading-relaxed text-white/80">서연 님의 드레스코드: {dressFull}</p><p className="mt-1 text-[12px] font-bold text-[#FFB59F]">현재 선택: {dressColorLabel} + {dressItemLabel}</p></div><div className="p-4 bg-white"><div className="flex items-center gap-3"><span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-black/10 text-xl" style={{background:(DRESS_COLORS.find(c=>c.id===dressColor)||DRESS_COLORS[0]).swatch}}>{(DRESS_ITEMS.find(i=>i.id===dressItem)||DRESS_ITEMS[0]).emoji}</span><div className="min-w-0"><p className="text-[14px] font-black text-[#1A1A1A]">{dressColorLabel} 상의</p><p className="text-[12px] font-bold text-[#5A534D]">{dressItemLabel}</p></div><span className="ml-auto shrink-0 rounded-full bg-[var(--sage-bg)] px-2.5 py-1 text-[11px] font-black text-[#4F7A5D]">둘 다 같은 신호</span></div><p className="mt-3 text-[11px] leading-relaxed text-[#5A534D]">두 분 모두 같은 색깔 상의와 같은 소품으로 서로를 알아봐요.</p></div></div>
              {dressStatus === 'editing' && (<><button onClick={proposeDress} className="mt-4 w-full rounded-2xl bg-[#E85D3F] py-4 text-[16px] font-black text-white shadow-sm">드레스코드 제안하기</button><button onClick={()=>{ setView('main'); setTab('calendar'); showToast('드레스코드는 다음에 정할 수 있어요'); }} className="mt-2 w-full rounded-2xl border-2 border-[#F0D9C8] bg-white py-3.5 text-[15px] font-black text-[#1A1A1A]">다음에 정할게요</button><p className="mt-2 text-center text-[11px] font-bold text-[#5A534D]">제안하면 상대가 좋아요 또는 변경을 선택해요.</p></>)}
              {dressStatus === 'proposed' && (<div className="mt-4 rounded-[22px] border border-[#F0D9C8] bg-white p-4 shadow-sm"><p className="text-[14px] font-black text-[#1A1A1A]">서연 님에게 제안했어요</p><p className="mt-1 text-[12px] leading-relaxed text-[#5A534D]">제안한 드레스코드: {dressFull} · 상대 응답을 기다리는 미리보기예요.</p><p className="mt-3 rounded-xl bg-[#FFF1EB] px-3 py-2 text-center text-[12px] font-black text-[#C94A30]">변경 가능 {dressChangesLeft}회 남음</p><p className="mt-3 text-[12px] font-black text-[#1A1A1A]">상대 응답 미리보기</p><div className="mt-2 flex gap-2"><button onClick={partnerLikeDress} className="flex-1 rounded-xl bg-[var(--sage-bg)] py-3 text-[14px] font-black text-[#4F7A5D]">좋아요</button><button disabled={dressChangesLeft<=0} onClick={partnerChangeDress} className="flex-1 rounded-xl border border-[#F0D9C8] bg-white py-3 text-[14px] font-black text-[#1A1A1A] disabled:opacity-50">다른 걸로 바꿀래요 (1회만)</button></div><button onClick={()=>{ setDressStatus('editing'); showToast('드레스코드를 다시 골라 보세요'); }} className="mt-2 w-full py-2 text-[12px] font-bold text-[#5A534D]">제안 다시 고르기</button></div>)}
              {dressStatus === 'confirmed' && (<div className="mt-4 rounded-[22px] bg-[var(--sage-bg)] p-4 text-center"><p className="mx-auto flex h-10 w-10 items-center justify-center rounded-full bg-[#6E9A7E] text-white"><Check size={20}/></p><p className="mt-2 text-[16px] font-black text-[#4F7A5D]">✓ 드레스코드가 확정됐어요</p><p className="mt-1 text-[13px] font-bold text-[#1A1A1A]">{dressFull}</p><p className="mt-1 text-[12px] font-bold text-[#5A534D]">양쪽 모두 동의했어요. 캘린더에서도 확인할 수 있어요.</p><button onClick={()=>{ setView('main'); setTab('calendar'); showToast('캘린더에서 드레스코드를 확인해 보세요'); }} className="mt-3 w-full rounded-xl bg-[var(--ink)] py-3.5 text-[14px] font-black text-white">캘린더에서 확인하기</button></div>)}
              <div className="mt-4 rounded-[22px] border border-[var(--line)] bg-[var(--surface)] p-4"><div className="flex items-center justify-between gap-2"><p className="flex items-center gap-2 text-[14px] font-black"><Vibrate size={16} className="text-[var(--accent)]"/>근접 진동 알림</p><button onClick={()=>{ const next=!proximityOn; setProximityOn(next); showToast(next?'근접 진동 알림을 켰어요':'근접 진동 알림을 껐어요'); }} className={`shrink-0 rounded-full px-3 py-1.5 text-[12px] font-black ${proximityOn ? 'bg-[var(--accent)] text-white' : 'bg-[var(--bg)] text-[var(--muted)]'}`}>{proximityOn ? '켜짐' : '꺼짐'}</button></div><p className="mt-2 text-[12px] leading-relaxed text-[var(--muted)]">근접 진동 알림은 양쪽 모두 동의했을 때만, 만남 30분 전부터 100m 이내에서 1회 울려요</p></div>
            </div>
          )}

          {stage === 'main' && view === 'feedback' && (
            <div className="px-5 pb-8 pt-3">
              <button onClick={()=>setView('main')} className="flex items-center gap-1 text-[13px] font-bold text-[var(--muted)]"><ArrowLeft size={16}/>뒤로</button>
              <div className="mt-6 text-center"><span className="text-4xl">☀️</span><h2 className="mt-3 text-[26px] font-black leading-tight">어제 애프터,<br/>어땠어요?</h2><p className="mx-auto mt-2 max-w-[280px] text-[13px] leading-relaxed text-[var(--muted)]">2차 애프터 · 다음날 아침 9시에 물어봐요.<br/>늦은 밤 만남을 배려했어요.</p></div>
              <div className="mt-5 flex items-center gap-3 rounded-[20px] bg-[var(--surface)] p-4 shadow-sm"><div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#F2A08D] text-lg font-black text-white">지</div><div><p className="font-black">지우 님과의 2번째 애프터</p><p className="text-[12px] text-[var(--muted)]">11/12 수 · 연남 산책 · 얼굴 인증 완료</p></div></div>
              <div className="mt-4 space-y-3">
                <button onClick={()=>{setFeedback('next'); setAfterCount(3); showToast('다음 애프터 신청을 보냈어요');}} className={`w-full rounded-[20px] border p-4 text-left ${feedback==='next'?'border-[var(--accent)] bg-[#FFF1EB]':'border-[var(--line)] bg-[var(--surface)]'}`}><p className="font-black">다음 애프터 신청하기 →</p><p className="mt-1 text-[12px] text-[var(--muted)]">좋은 만남이었어요. 또 만나고 싶어요.</p></button>
                <button onClick={()=>{setFeedback('think'); showToast('생각할 시간을 드릴게요. 하루 뒤 다시 물어볼게요.');}} className={`w-full rounded-[20px] border p-4 text-left ${feedback==='think'?'border-[var(--accent)] bg-[#FFF1EB]':'border-[var(--line)] bg-[var(--surface)]'}`}><p className="font-black">조금 더 생각해볼게요 <span className="ml-1 rounded-full bg-[var(--bg)] px-2 py-0.5 text-[11px] text-[var(--muted)]">1회만</span></p><p className="mt-1 text-[12px] text-[var(--muted)]">아직 확신이 서지 않아요. 한 번만 미룰게요.</p></button>
                <button onClick={()=>{setFeedback('no'); showToast('마음을 전했어요. 서로를 응원해요.');}} className={`w-full rounded-[20px] border p-4 text-left ${feedback==='no'?'border-[var(--accent)] bg-[#FFF1EB]':'border-[var(--line)] bg-[var(--surface)]'}`}><p className="font-black">다음에 만나지 않을래요</p><p className="mt-1 text-[12px] text-[var(--muted)]">이번 만남은 여기까지. 정중히 마무리해요.</p></button>
              </div>
              {afterCount >= 3 && (<div className="mt-5 overflow-hidden rounded-[24px] bg-[#2B2622] p-5 text-center text-white"><Sparkles className="mx-auto text-[#FFB59F]"/><h3 className="mt-2 text-[20px] font-black">3번째 애프터 완료!</h3><p className="mt-1 text-[13px] text-white/75">두 분 모두 “연애 시작하기”를 누르면<br/>애프터가 연애로 이어져요.</p><div className="mt-4 rounded-2xl bg-white/10 p-3 text-[12px]">상대 응답 대기 중 · 두 분의 선택을 기다려요</div><button onClick={()=>showToast('연애 시작하기 의사를 전달했어요 💛')} className="mt-3 w-full rounded-xl bg-[var(--accent)] py-3.5 text-[15px] font-black text-white">연애 시작하기</button></div>)}
              <p className="mt-4 text-center text-[11px] text-[var(--muted)]">피드백은 상대에게 점수로 공개되지 않아요.</p>
            </div>
          )}

{stage === 'main' && (view === 'checkin' || view === 'code') && (
            <div className="px-5 pb-8 pt-3"><button onClick={()=>setView('main')} className="flex items-center gap-1 text-[13px] font-bold text-[var(--muted)]"><ArrowLeft size={16}/>뒤로</button><div className="mt-8 text-center"><p className="text-[12px] font-black tracking-widest text-[var(--accent)]">MEETING CODE</p><h2 className="mt-2 text-[24px] font-black">만남 코드 보기</h2><p className="mt-2 text-[13px] text-[var(--muted)]">현장에서 서로 확인하는 코드예요.<br/>전화번호 대신 이 코드를 사용해요.</p><div className="mx-auto mt-6 flex h-36 w-36 flex-col items-center justify-center rounded-[28px] border-2 border-dashed border-[var(--accent)] bg-[var(--surface)]"><span className="text-[12px] font-bold text-[var(--muted)]">11/19 수 · 3차 애프터</span><span className="serif text-[42px] font-black tracking-widest">A-4821</span><span className="text-[11px] font-bold text-[var(--accent)]">지우 님과의 만남</span></div><p className="mt-4 text-[12px] text-[var(--muted)]">만남 2시간 전부터 확인할 수 있어요.</p></div><div className="mt-6 rounded-[24px] border border-[var(--line)] bg-[var(--surface)] p-4"><div className="flex items-center gap-2"><Palette size={17} className="text-[var(--accent)]"/><h3 className="text-[15px] font-black">오늘의 드레스코드</h3>{dressConfirmed && <span className="rounded-full bg-[var(--sage-bg)] px-2 py-0.5 text-[10px] font-black text-[#4F7A5D]">정해졌어요</span>}</div><p className="mt-1 text-[12px] leading-relaxed text-[var(--muted)]">코드만 외우지 않아도 돼요. 멀리서도 알아볼 수 있는 가벼운 신호를 둘 다 맞춰요.</p><p className="mt-3 text-[12px] font-black">1 · 색깔 신호</p><div className="mt-2 grid grid-cols-4 gap-2">{DRESS_COLORS.map(c => <button key={c.id} onClick={()=>{ setDressColor(c.id); setDressConfirmed(false); }} className={`rounded-2xl border p-2 text-center ${dressColor===c.id ? 'border-[var(--accent)] bg-[#FFF1EB]' : 'border-[var(--line)]'}`}><span className="mx-auto block h-6 w-6 rounded-full border border-black/10" style={{background:c.swatch}}/><span className="mt-1 block text-[11px] font-black">{c.label}</span></button>)}</div><p className="mt-3 text-[12px] font-black">2 · 손에 들고 올 것</p><div className="mt-2 grid grid-cols-2 gap-2">{DRESS_ITEMS.map(i => <button key={i.id} onClick={()=>{ setDressItem(i.id); setDressConfirmed(false); }} className={`rounded-2xl border p-3 text-left ${dressItem===i.id ? 'border-[var(--accent)] bg-[#FFF1EB]' : 'border-[var(--line)]'}`}><span className="text-xl">{i.emoji}</span><span className="mt-1 block text-[12px] font-black">{i.label}</span></button>)}</div><div className="mt-4 rounded-2xl bg-[var(--bg)] p-3 text-center"><p className="text-[11px] font-bold text-[var(--muted)]">둘 다 이렇게 만나요</p><p className="mt-1 text-[14px] font-black">{dressColorDesc} + {dressItemLabel}</p></div><button onClick={()=>{ setDressConfirmed(true); showToast('드레스코드가 정해졌어요'); }} className="mt-3 w-full rounded-xl bg-[var(--accent)] py-3.5 text-[14px] font-black text-white">{dressConfirmed ? '드레스코드 다시 정하기' : '이 드레스코드로 정하기'}</button><p className="mt-2 text-center text-[11px] text-[var(--muted)]">상대에게도 같은 신호가 보여요. 부담 없는 소품으로 정해요.</p></div><div className="mt-4 rounded-[24px] border border-[var(--line)] bg-[var(--surface)] p-4"><div className="flex items-center justify-between gap-2"><div className="flex items-center gap-2"><Vibrate size={17} className="text-[var(--accent)]"/><h3 className="text-[15px] font-black">가까워지면 진동</h3></div><button onClick={()=>{ const next = !proximityOn; setProximityOn(next); if (next) { buzz([60,40,60]); showToast('진동 알림을 켰어요'); } else { setProximityDistance(null); showToast('진동 알림을 껐어요'); } }} className={`shrink-0 rounded-full px-3 py-1.5 text-[12px] font-black ${proximityOn ? 'bg-[var(--accent)] text-white' : 'bg-[var(--bg)] text-[var(--muted)]'}`}>{proximityOn ? '켜짐' : '꺼짐'}</button></div><p className="mt-1 text-[12px] leading-relaxed text-[var(--muted)]">상대가 근처에 오면 핸드폰이 진동으로 알려줘요. 고개를 들고 주변을 둘러보면 돼요.</p><div className={`mt-3 rounded-2xl p-3 text-center ${proximityDistance !== null && proximityDistance <= 15 ? 'bg-[#FFF1EB]' : 'bg-[var(--bg)]'}`}><p className="text-[11px] font-bold text-[var(--muted)]">지금 상대와의 거리 미리보기</p><p className="mt-1 text-[18px] font-black">{!proximityOn ? '알림 꺼짐' : proximityDistance === null ? '아직 확인 전' : proximityDistance === 0 ? '도착했어요 · 드레스코드를 확인해 보세요' : `약 ${proximityDistance}m`}</p>{proximityDistance !== null && proximityDistance <= 15 && proximityDistance > 0 && <p className="mt-1 text-[12px] font-bold text-[var(--accent)]">가까워요 · {dressColorDesc} + {dressItemLabel}을 찾아보세요</p>}</div><button onClick={advanceProximity} className="mt-3 w-full rounded-xl bg-[var(--ink)] py-3.5 text-[14px] font-black text-white">{proximityDistance === null ? '도착 알림 확인해 보기' : proximityDistance === 0 ? '알림 다시 시작하기' : '한 걸음 더 가까워졌다고 해 보기'}</button><p className="mt-2 text-center text-[11px] leading-relaxed text-[var(--muted)]">실제 위치를 계속 공유하지 않아요. 만남 시간에만 켜져요.<br/>이 버튼은 미리보기예요 · 기기가 진동을 지원하면 함께 울려요.</p></div></div>
          )}

          {stage === 'main' && view === 'profile' && selectedProfile && (() => { const p = selectedProfile; const detail = PROFILE_DETAILS[p.id] || PROFILE_DETAILS[1]; const already = applied.includes(p.id); const isTranslated = p.origLang !== uiLang; const dressForThisPerson = p.id === 2 && dressConfirmed; return (
            <div className="flex min-h-full flex-col px-5 pb-4 pt-3">
              <button onClick={closeProfile} className="flex w-fit items-center gap-1 rounded-full bg-[var(--surface)] px-3 py-2 text-[13px] font-black text-[var(--ink)] shadow-sm"><ArrowLeft size={16}/>&lt; 뒤로</button>
              <div className="mt-4 overflow-hidden rounded-[28px] border border-[var(--line)] bg-[var(--surface)] shadow-sm">
                <div className="relative flex h-[240px] flex-col items-center justify-center px-5 text-center text-white" style={{background: p.grad}}>
                  <span className="absolute left-4 top-4 rounded-full bg-black/25 px-3 py-1.5 text-[11px] font-black">프로필 사진 · 플레이스홀더</span>
                  <span className="flex h-[112px] w-[112px] items-center justify-center rounded-full border-4 border-white/80 text-[52px] font-black shadow-lg">{p.initial}</span>
                  {p.faceVerified && <span className="mt-4 flex items-center gap-1.5 rounded-full bg-white px-3.5 py-1.5 text-[12px] font-black text-[#2B5A3E]"><BadgeCheck size={15}/>얼굴 인증 완료</span>}
                </div>
                <div className="p-5">
                  <div className="flex flex-wrap items-start justify-between gap-3"><div><h2 className="text-[28px] font-black leading-none">{p.name} · {p.age}세</h2><p className="mt-2 flex items-center gap-1 text-[12px] font-bold text-[var(--muted)]"><ShieldCheck size={14} className="text-[#6E9A7E]"/>나이 {p.age}세 · 본인인증으로 확인됨</p></div><span className={`rounded-full px-3 py-1.5 text-[11px] font-black ${p.verified ? 'bg-[var(--sage-bg)] text-[#4F7A5D]' : 'bg-[#FFF6E6] text-[#9A6A1A]'}`}>{p.badge}</span></div>
                  <div className="mt-4 grid grid-cols-2 gap-2 text-left"><div className="rounded-2xl bg-[var(--bg)] p-3"><p className="text-[11px] font-bold text-[var(--muted)]">활동 지역</p><p className="mt-1 text-[14px] font-black">{p.area}</p></div><div className="rounded-2xl bg-[var(--bg)] p-3"><p className="text-[11px] font-bold text-[var(--muted)]">직업</p><p className="mt-1 text-[14px] font-black">{p.job}</p></div></div>
                  <p className="mt-3 text-[12px] leading-relaxed text-[var(--muted)]">전화번호는 공개되지 않아요. 만남은 만남 코드로만 연결돼요.</p>
                </div>
              </div>
              <div className="mt-4 rounded-[24px] border border-[var(--line)] bg-[var(--surface)] p-5">
                <div className="flex items-center justify-between gap-2"><h3 className="flex items-center gap-2 text-[16px] font-black"><Languages size={17} className="text-[var(--accent)]"/>자기소개</h3>{isTranslated && <span className="flex items-center gap-1 rounded-full bg-[var(--sage-bg)] px-2.5 py-1 text-[10px] font-black text-[#4F7A5D]"><Languages size={11}/>자동 번역됨</span>}</div>
                <div className="mt-3 flex rounded-full bg-[var(--bg)] p-1"><button onClick={()=>setDetailIntroTab('translated')} className={`flex-1 rounded-full py-2 text-[12px] font-black ${detailIntroTab==='translated' ? 'bg-[var(--accent)] text-white' : 'text-[var(--muted)]'}`}>번역본 보기</button><button onClick={()=>setDetailIntroTab('original')} className={`flex-1 rounded-full py-2 text-[12px] font-black ${detailIntroTab==='original' ? 'bg-[var(--ink)] text-white' : 'text-[var(--muted)]'}`}>원문 보기</button></div>
                <p className="mt-3 text-[11px] font-black text-[var(--muted)]">{detailIntroTab==='translated' ? `번역본 · ${LANG_LABEL[uiLang]}` : `원문 · ${LANG_LABEL[p.origLang]}`}</p>
                <p className="mt-1.5 text-[15px] font-bold leading-relaxed">{detailIntroTab==='translated' ? p.introByLang[uiLang] : p.intro}</p>
                {isTranslated && <p className="mt-3 flex items-center gap-1 text-[11px] font-bold text-[#4F7A5D]"><Languages size={12}/>자동 번역됨 · 자동 번역으로 뉘앙스가 다를 수 있어요</p>}
                {detailIntroTab==='translated' && p.origLang !== uiLang && <p className="mt-2 rounded-xl bg-[var(--bg)] p-3 text-[12px] leading-relaxed text-[var(--muted)]">원문 미리보기 · {p.intro}</p>}
              </div>
              <div className="mt-4 rounded-[24px] border border-[var(--line)] bg-[var(--surface)] p-5">
                <h3 className="flex items-center gap-2 text-[16px] font-black"><MessageCircle size={17} className="text-[var(--accent)]"/>첫 만남에서 이런 얘기 하고 싶어요</h3>
                <div className="mt-3 space-y-3">{detail.qa.map((item, i) => <div key={item.q} className="rounded-2xl bg-[var(--bg)] p-3.5"><p className="text-[13px] font-black">Q{i+1}. {item.q}</p><p className="mt-1.5 text-[13px] leading-relaxed">{item.a}</p></div>)}</div>
              </div>
              <div className="mt-4 rounded-[24px] border border-[var(--line)] bg-[var(--surface)] p-5">
                <h3 className="text-[16px] font-black">이상형 / 데이트 스타일</h3>
                <p className="mt-3 text-[12px] font-black text-[var(--muted)]">만나고 싶은 유형</p><div className="mt-2 flex flex-wrap gap-2">{detail.types.map(t => <span key={t} className="rounded-full bg-[#FFF1EB] px-3 py-1.5 text-[12px] font-black text-[#9A3B25]">{t}</span>)}</div>
                <p className="mt-4 text-[12px] font-black text-[var(--muted)]">데이트 스타일</p><div className="mt-2 flex flex-wrap gap-2">{detail.styles.map(s => <span key={s} className="rounded-full bg-[var(--sage-bg)] px-3 py-1.5 text-[12px] font-black text-[#4F7A5D]">{s}</span>)}</div>
                <p className="mt-4 text-[12px] font-black text-[var(--muted)]">만날 수 있는 시간대</p><div className="mt-2 flex flex-wrap gap-2">{detail.times.map(t => <span key={t} className="rounded-full bg-[var(--bg)] px-3 py-1.5 text-[12px] font-black">{t}</span>)}</div>
              </div>
              <div className="mt-4 rounded-[24px] border border-[var(--line)] bg-[var(--surface)] p-5">
                <h3 className="flex items-center gap-2 text-[16px] font-black"><CalendarDays size={17} className="text-[var(--accent)]"/>만날 수 있는 날짜</h3><p className="mt-1 text-[12px] text-[var(--muted)]">원하는 날짜를 골라 보세요. 신청할 때 함께 전달돼요.</p>
                <div className="mt-3 space-y-2">{p.dates.map(d => { const selected = detailDate === d; return <button key={d} onClick={()=>setDetailDate(d)} className={`flex w-full items-center gap-3 rounded-2xl border-2 p-3.5 text-left ${selected ? 'border-[var(--accent)] bg-[#FFF1EB]' : 'border-[var(--line)] bg-[var(--bg)]'}`}><span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 ${selected ? 'border-[var(--accent)] bg-[var(--accent)] text-white' : 'border-[var(--line)] bg-white'}`}>{selected && <Check size={13} strokeWidth={3}/>}</span><span className="flex-1 text-[14px] font-black">{d}</span>{selected && <span className="text-[11px] font-black text-[var(--accent)]">선택됨</span>}</button>; })}</div>
              </div>
              <div className="mt-4 rounded-[24px] border border-[var(--line)] bg-[var(--surface)] p-5">
                <h3 className="flex items-center gap-2 text-[16px] font-black"><Palette size={17} className="text-[var(--accent)]"/>드레스코드</h3>
                {dressForThisPerson ? <div className="mt-3"><p className="flex items-center gap-2 text-[14px] font-black"><span className="h-5 w-5 rounded-full border border-black/10" style={{background:(DRESS_COLORS.find(c=>c.id===dressColor)||DRESS_COLORS[0]).swatch}}/>{dressFull}</p><p className="mt-1.5 flex items-center gap-1 text-[12px] font-bold text-[#4F7A5D]"><Check size={13}/>양쪽 모두 동의했어요</p></div> : <p className="mt-3 text-[13px] leading-relaxed">아직 정해지지 않았어요 · 신청이 수락되면 함께 정해요.</p>}
                {dressForThisPerson && <p className="mt-2 text-[12px] text-[var(--muted)]">선택한 날짜 · {detailDate || '날짜를 선택해 주세요'}</p>}
              </div>
              <div className="sticky bottom-0 -mx-5 mt-5 border-t border-[var(--line)] bg-[var(--bg)] px-5 pb-2 pt-3">
                {already && <p className="mb-2 rounded-xl bg-[var(--sage-bg)] p-3 text-center text-[12px] font-black text-[#4F7A5D]">신청 완료 · 상대 응답 대기 (24시간)</p>}
                <div className="flex gap-2"><button onClick={()=>{ if(!already) showToast('데이트 신청이 전송됐어요 · 상대 응답 대기 24시간'); applyFromDetail(p); }} className={`flex-1 rounded-2xl py-4 text-[15px] font-black ${already ? 'bg-[var(--sage-bg)] text-[#4F7A5D]' : 'bg-[var(--accent)] text-white'}`}>{already ? '신청 완료 · 상대 응답 대기 (24시간)' : '데이트 신청하기'}</button><button onClick={()=>{ showToast('다음에 볼 사람으로 남겨뒀어요'); closeProfile(); }} className="flex-1 rounded-2xl border-2 border-[var(--line)] bg-[var(--surface)] py-4 text-[15px] font-black">다음에 보기</button></div>
                {detailDate ? <p className="mt-2 text-center text-[11px] font-bold text-[var(--muted)]">선택한 날짜 · {detailDate}</p> : <p className="mt-2 text-center text-[11px] font-bold text-[var(--muted)]">날짜를 선택하면 신청과 함께 전달돼요</p>}
              </div>
            </div>
          )})()}
          {stage === 'main' && view === 'share' && (
            <div className="px-5 pb-8 pt-3"><button onClick={()=>setView('main')} className="flex items-center gap-1 text-[13px] font-bold text-[var(--muted)]"><ArrowLeft size={16}/>뒤로</button><div className="mt-4"><SectionTitle kicker="SAFETY" title="지인에게 일정 공유하기" sub="전화번호 없이, 만남 정보만 전달해요." /></div><label className="mt-5 block text-[12px] font-bold text-[var(--muted)]">공유할 내용 미리보기</label><textarea ref={shareRef} readOnly value={"[애프터 일정 공유]\n11/19 수 19:00 · 성수 카페\n만남 코드 A-4821 · 21:00까지 연락 예정\n전화번호는 공유되지 않아요."} rows={5} className="mt-2 w-full rounded-2xl border border-[var(--line)] bg-[var(--surface)] p-4 text-[13px] leading-relaxed" /><button onClick={copyShare} className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl bg-[var(--accent)] py-4 text-[15px] font-black text-white"><Copy size={17}/>내용 복사하기</button>{shareDone && <p className="mt-3 rounded-xl bg-[var(--sage-bg)] p-3 text-center text-[12px] font-bold text-[#4F7A5D]">복사 완료! 지인에게 붙여넣어 공유해 보세요.</p>}<p className="mt-4 text-[11px] leading-relaxed text-[var(--muted)]">공유에는 상대의 이름이나 연락처가 포함되지 않아요.</p></div>
          )}

          {stage === 'main' && view === 'report' && (
            <div className="px-5 pb-8 pt-3">
              <button onClick={closeReport} className="flex items-center gap-1 text-[13px] font-bold text-[var(--muted)]"><ArrowLeft size={16}/>뒤로</button>
              <div className="mt-4"><SectionTitle kicker="SAFETY" title="신고하기" sub="불편했던 순간이 있었다면, 안전하게 알려주세요. 상대에게는 신고 사실이 표시되지 않아요." /></div>
              <div className="mt-5 flex items-center gap-3 rounded-[22px] border border-[var(--line)] bg-[var(--surface)] p-4">
                {reportTarget ? <><div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl text-[24px] font-black text-white" style={{ background: reportTarget.grad }}>{reportTarget.initial}</div><div className="min-w-0"><p className="text-[16px] font-black">{reportTarget.name} · {reportTarget.age}세</p><p className="mt-0.5 text-[12px] text-[var(--muted)]">{reportTarget.area} · {reportTarget.job} · {reportTarget.badge}</p><p className="mt-1 text-[11px] font-bold text-[var(--muted)]">신고 대상</p></div></> : <><div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-[var(--bg)] text-[24px]">🚨</div><div><p className="text-[16px] font-black">신고 대상 선택 전</p><p className="mt-0.5 text-[12px] leading-relaxed text-[var(--muted)]">프로필이나 일정에서 신고할 상대를 골라 주세요.</p></div></>}
              </div>
              <div className="mt-4 rounded-[22px] border border-[var(--line)] bg-[var(--surface)] p-4"><p className="text-[14px] font-black">신고 사유 <span className="text-[11px] font-bold text-[var(--muted)]">· 해당되는 항목을 모두 선택해 주세요</span></p><div className="mt-3 space-y-2">{REPORT_REASONS.map(reason => { const checked = reportReasons.includes(reason); return <button key={reason} onClick={() => setReportReasons(prev => prev.includes(reason) ? prev.filter(x => x !== reason) : [...prev, reason])} className={`flex w-full items-center gap-3 rounded-2xl border-2 p-3.5 text-left ${checked ? 'border-[var(--accent)] bg-[#FFF1EB]' : 'border-[var(--line)] bg-[var(--bg)]'}`}><span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md border-2 ${checked ? 'border-[var(--accent)] bg-[var(--accent)] text-white' : 'border-[var(--line)] bg-white'}`}>{checked && <Check size={13} strokeWidth={3}/>}</span><span className="flex-1 text-[14px] font-black">{reason}</span>{checked && <span className="text-[11px] font-black text-[var(--accent)]">선택됨</span>}</button>; })}</div></div>
              <div className="mt-4 rounded-[22px] border border-[var(--line)] bg-[var(--surface)] p-4"><label className="text-[14px] font-black" htmlFor="report-detail">자세히 적어주세요 (선택)</label><textarea id="report-detail" value={reportText} onChange={e => setReportText(e.target.value)} placeholder="언제, 어떤 일이 있었는지 적어 주세요. 상대에게는 신고 사실이 표시되지 않아요." rows={4} className="mt-3 w-full resize-none rounded-xl border border-[var(--line)] bg-[var(--bg)] p-3.5 text-[13px] leading-relaxed outline-none focus:border-[var(--accent)]" /><p className="mt-3 flex items-start gap-2 rounded-xl bg-[var(--bg)] p-3 text-[12px] leading-relaxed text-[var(--muted)]"><span>📎</span><span>스크린샷이나 영수증이 있으면 도움이 돼요</span></p></div>
              <div className="mt-4 flex items-start gap-2 rounded-[18px] bg-[#2B2622] p-4 text-[12px] leading-relaxed text-white"><span>⚠️</span><span><b>거짓 신고 시에도 동일하게 일시정지돼요</b><br/>확인되는 사실만 적어 주세요.</span></div>
              <button onClick={submitReport} className="mt-4 w-full rounded-2xl bg-[var(--ink)] py-4 text-[15px] font-black text-white">신고 제출하기</button>
              <button onClick={closeReport} className="mt-2 w-full rounded-2xl border-2 border-[var(--line)] bg-[var(--surface)] py-3.5 text-[14px] font-black">돌아가기</button>
            </div>
          )}
        </div>

        {stage === 'main' && view === 'main' && (
          <nav className="border-t border-[var(--line)] bg-[var(--surface)] px-2 pb-[max(10px,env(safe-area-inset-bottom))] pt-2">
            <div className="grid grid-cols-4">{([['home','홈',Home],['recommend','추천',Sparkles],['calendar','캘린더',CalendarDays],['my','마이',Users]] as [Tab,string,typeof Home][]).map(([k,label,Icon]) => <button key={k} onClick={()=>setTab(k)} className={`flex flex-col items-center gap-1 rounded-xl py-2 text-[11px] font-bold ${tab===k?'text-[var(--accent)]':'text-[var(--muted)]'}`}><Icon size={20}/>{label}</button>)}</div>
          </nav>
        )}
        <Toast text={toast} />
      </div>
      <div className="pointer-events-none fixed bottom-3 left-1/2 hidden -translate-x-1/2 rounded-full bg-black/70 px-3 py-1 text-[10px] text-white sm:block">프로토타입 미리보기 · 실제 전송되지 않아요</div>
    </div>
  );
}
